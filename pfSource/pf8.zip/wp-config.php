<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wplab6');

/** MySQL database username */
define('DB_USER', 'wplab6');

/** MySQL database password */
define('DB_PASSWORD', 'wplab6');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '~2X= s@RzdB(yYfc(!]oEQFJp2-#<<szg<s5{%>*:qU_4PC$Sac8`{,$^o1_e;5>');
define('SECURE_AUTH_KEY',  'Eb|D=D_vfacGf(5l%k+(om8}?4c=fUQa|`w$0A%}2oU3:U%,41)@L0D;^[}tYlC4');
define('LOGGED_IN_KEY',    'eEs|dT)K#i,iO,pIx4H&5o0t2&snd l7psw$SdG-cv<5d_buYcwpn 2;j->PFPF9');
define('NONCE_KEY',        '(Uq>$-ZJL2LIM4ge:J!7UHGuc]C/tX2RU[H-<cDG]9bqr)[rX%gS5LJMU=&vrz-T');
define('AUTH_SALT',        '9H{ }FOxFAffgE?7z`>2WWPbx9`q1gPrM/878y)<TlfLO`>phe`jKs*)gYe2B:h3');
define('SECURE_AUTH_SALT', '1Om&g5I*ljh+m U|g3q+FrE1V(4.[&{j`#[z|SSg@Fq%kJ(L/%qpH)o4kTk=1e$Q');
define('LOGGED_IN_SALT',   'f;Bg873c|ZSVG{NavQ2Mi5*i3{yTdMxZ&R&(;+|cElMqb@_tv@r!#Pf}.yNICJ_n');
define('NONCE_SALT',       '{ {_vi;v]ua/wPo8p/$H&k>2P%B`_hPP[Kx7zg;Mx;`>Ub-_f*_wtPzpEY-HO^5K');


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';


/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */

// enable debug
define( 'WP_DEBUG', true );

// log debug info in log file
define( 'WP_DEBUG_LOG', true );

// display debug info directly on HTML pages
define( 'WP_DEBUG_DISPLAY', false );

// save queries
define( 'SAVEQUERIES', false );



/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
