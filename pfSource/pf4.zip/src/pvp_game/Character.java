package pvp_game;

public class Character {

 	private String Name; // Play Chracter's name (such as 'Archer') or Monsters' name
    private int Hp; // character health
    private int Attack; // character attack power
  	private int Deffense; // character defense power
    
	//Get & Set Method
 	public String getName() {
 		return Name;
 	}
 	
 	public void setName(String name) {
 		Name = name;
 	}
 	
 	public int getHp() {
 		return Hp;
 	}
 	
 	public void setHp(int hp) {
 		Hp = hp;
 	}
 
 	public int getAttack() {
		return Attack;
	}
 	
	public void setAttack(int attack) {
		Attack = attack;
	}

 	public int getDeffense() {
 		return Deffense;
 	}
 	
 	public void setDeffense(int deffense) {
 		Deffense = deffense;
 	}
 	
 		
 	//Constructor
    public Character(String name, int hp, int attack, int deffense) {
		Name = name;
		Hp = hp;
		Attack = attack;
		Deffense = deffense;
	}

}
