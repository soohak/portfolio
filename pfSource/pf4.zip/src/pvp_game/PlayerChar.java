package pvp_game;

public class PlayerChar extends Character{
	
	private int CharType; //1: Archer, 2: Swrodsman, 3: Spearman 
	private int Gold; //gained gold
	private boolean[] Items;
	

	//Get & Set Method
	public int getCharType() {
		return CharType;
	}
	public void setCharType(int CType) {
		CharType = CType;
	}
	public int getGold() {
		return Gold;
	}
	public void setGold(int gold) {
		Gold = gold;
	}
	public boolean getItems(int index) {
		return Items[index];
	}
	
	//overloading
	public void setItems(int index, boolean items) {
		Items[index] = items;
	}
	
	public void setItems(int index1, int index2, int index3) {
		Items[index1] = false;
		Items[index2] = false;
		Items[index3] = false;
	}

	//Constructor
	public PlayerChar(String name, int hp, int attack, int deffense, int charType, int gold, int index) {
		super(name, hp, attack, deffense);
		CharType = charType;
		Gold = gold;
		Items = new boolean[index];
	}	
	
}
