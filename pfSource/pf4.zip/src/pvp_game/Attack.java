package pvp_game;

public class Attack {
	
	private String CombatInfo;
	private boolean attackSuccess;
	 
	//constructor
	public Attack(String combatInfo, boolean attackSuccess) {
		super();
		CombatInfo = combatInfo;
		this.attackSuccess = attackSuccess;
	}
	
	//Attack Process
	public boolean attackResult() {
		int PlayAtt;
		int MonAtt;
		
		PlayAtt = (int)(Math.random()*7+1);
		MonAtt = (int)(Math.random()*6+1);
		
		if(PlayAtt>MonAtt) {
			this.setAttackSuccess(true);
			return this.attackSuccess;
		}
		else {
			this.setAttackSuccess(false);
			return this.attackSuccess;
		}
	}



	//get & set methods
	public boolean isAttackSuccess() {
		return attackSuccess;
	}

	public void setAttackSuccess(boolean attackSuccess) {
		this.attackSuccess = attackSuccess;
	}

	public String getCombatInfo() {
		return CombatInfo;
	}

	public void setCombatInfo(String combatInfo) {
		CombatInfo = combatInfo;
	}
	 
	 
}
