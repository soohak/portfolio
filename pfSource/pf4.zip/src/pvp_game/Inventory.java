package pvp_game;

public class Inventory {
	private int APstr;
	private int DPstr;
	private int HPstr;
	private int ApGold;
	private int DpGold;
	private int HpGold;
	
	//constructor
	public Inventory(int aPstr, int dPstr, int hPstr, int apGold, int dpGold, int hpGold) {
		//super();
		APstr = aPstr;
		DPstr = dPstr;
		HPstr = hPstr;
		ApGold = apGold;
		DpGold = dpGold;
		HpGold = hpGold;
	}

	//get&set method
	public int getAPstr() {
		return APstr;
	}

	public void setAPstr(int aPstr) {
		APstr = aPstr;
	}

	public int getDPstr() {
		return DPstr;
	}

	public void setDPstr(int dPstr) {
		DPstr = dPstr;
	}

	public int getHPstr() {
		return HPstr;
	}

	public void setHPstr(int hPstr) {
		HPstr = hPstr;
	}

	public int getApGold() {
		return ApGold;
	}

	public void setApGold(int apGold) {
		ApGold = apGold;
	}

	public int getDpGold() {
		return DpGold;
	}

	public void setDpGold(int dpGold) {
		DpGold = dpGold;
	}

	public int getHpGold() {
		return HpGold;
	}

	public void setHpGold(int hpGold) {
		HpGold = hpGold;
	} 
	
}
