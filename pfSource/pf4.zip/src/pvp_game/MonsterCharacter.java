package pvp_game;

public class MonsterCharacter extends Character{
	private int MonsterID; //ID for each monster characters 

	//Get & Set Method
	public int getMonsterID() {
		return MonsterID;
	}

	public void setMonsterID(int MId) {
		MonsterID = MId;
	}
	
	//Constructor
	public MonsterCharacter(String name, int hp, int attack, int deffense, int monsterID) {
		super(name, hp, attack, deffense);
		MonsterID = monsterID;
	}
}
