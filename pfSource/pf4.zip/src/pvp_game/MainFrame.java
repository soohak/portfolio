package pvp_game;

//import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import java.awt.SystemColor;
//import javax.swing.JTextField;

//import java.util.Timer;
//import java.util.TimerTask;


public class MainFrame extends JFrame {

	private JPanel contentPane;

	public static final int SCREEN_WIDTH = 960;
	public static final int SCREEN_HEIGHT = 600;
	public static int selectedType;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//Object instance for Player, Monster and Inventory, set default values
	PlayerChar Player = new PlayerChar("Default", 0, 0, 0, 0, 0,3);  //Player Character object
	MonsterCharacter Monster = new MonsterCharacter("Default", 0, 0, 0, 0); //Monster Character object
	Inventory Items = new Inventory(5, 5, 5, 10, 15, 20); //Inventory object 
	Attack playAttack = new Attack("Battale Information", false);//Attack object
			
	/**
	 * Create the frame. 
	 */
	public MainFrame() {
		setTitle("Dungeon Warrior");
		setSize(MainFrame.SCREEN_WIDTH, MainFrame.SCREEN_HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		//Main start screen
		JPanel StartScr = new JPanel();
		contentPane.add(StartScr, "name_13410580103345");
		StartScr.setLayout(null);
		
		//Character setting screen
		JPanel CharSet = new JPanel();
		CharSet.setBackground(new Color(255, 255, 255));
		contentPane.add(CharSet, "name_13410605433873");
		CharSet.setLayout(null);
		
		//Inventory screen
		JPanel Inventory = new JPanel();
		contentPane.add(Inventory, "name_13410655252261");
		Inventory.setLayout(null);
		
		//Game play screen
		JPanel PlayScr = new JPanel();
		contentPane.add(PlayScr, "name_13410629646256");
		PlayScr.setLayout(null);
		
		//Start Button in Main		
		JButton Start = new JButton("Game Start");
		Start.setFont(new Font("Tahoma", Font.BOLD, 14));
		Start.setForeground(new Color(255, 255, 255));
		Start.setBackground(new Color(0, 153, 153));
		Start.setBounds(621, 472, 132, 38);
		StartScr.add(Start);
		
		//Exit Button in Main		
		JButton exit = new JButton("Exit");
		exit.setForeground(Color.WHITE);
		exit.setFont(new Font("Tahoma", Font.BOLD, 14));
		exit.setBackground(new Color(102, 51, 51));
		exit.setBounds(763, 472, 131, 38);
		StartScr.add(exit);
		
		//Player name
		JLabel lblCharName = new JLabel("Character");
		lblCharName.setForeground(new Color(0, 0, 128));
		lblCharName.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblCharName.setBounds(20, 30, 101, 25);
		PlayScr.add(lblCharName);
		
		//Monster name
		JLabel lblMonName = new JLabel("Monster");
		lblMonName.setForeground(new Color(255, 0, 0));
		lblMonName.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblMonName.setBounds(350, 30, 101, 25);
		PlayScr.add(lblMonName);
		
		//Indicate player HP
		JLabel lblPlayerHP = new JLabel("HP");
		lblPlayerHP.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPlayerHP.setForeground(new Color(255, 0, 0));
		lblPlayerHP.setBounds(264, 437, 90, 31);
		PlayScr.add(lblPlayerHP);
		
		//Indicate player attack power
		JLabel lblPlayerattack = new JLabel("Attack");
		lblPlayerattack.setForeground(new Color(0, 51, 255));
		lblPlayerattack.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPlayerattack.setBounds(263, 460, 77, 31);
		PlayScr.add(lblPlayerattack);
		
		//Indicate player armor
		JLabel lblPlayerDefense = new JLabel("Defense");
		lblPlayerDefense.setForeground(new Color(0, 51, 255));
		lblPlayerDefense.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPlayerDefense.setBounds(263, 482, 90, 31);
		PlayScr.add(lblPlayerDefense);
		
		//Indicate player's gold
		JLabel lblGold = new JLabel("Gold");
		lblGold.setBackground(new Color(255, 255, 255));
		lblGold.setForeground(new Color(255, 140, 0));
		lblGold.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		lblGold.setBounds(20, 496, 101, 25);
		PlayScr.add(lblGold);

		//Indicate monster HP
		JLabel lblMonsterHp = new JLabel("HP");
		lblMonsterHp.setForeground(new Color(0, 0, 255));
		lblMonsterHp.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMonsterHp.setBounds(581, 30, 70, 31);
		PlayScr.add(lblMonsterHp);
		
		//Indicate monster attack power
		JLabel lblMonstgerAttack = new JLabel("Attack");
		lblMonstgerAttack.setForeground(new Color(255, 0, 0));
		lblMonstgerAttack.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblMonstgerAttack.setBounds(581, 52, 90, 31);
		PlayScr.add(lblMonstgerAttack);
		
		//Indicate monster armor
		JLabel lalMonsterDeffense = new JLabel("Defense");
		lalMonsterDeffense.setBackground(new Color(255, 255, 255));
		lalMonsterDeffense.setForeground(new Color(255, 0, 0));
		lalMonsterDeffense.setFont(new Font("Tahoma", Font.BOLD, 14));
		lalMonsterDeffense.setBounds(581, 75, 90, 31);
		PlayScr.add(lalMonsterDeffense);
		
		//Player's character image in play screen
		JLabel lblPlayerImg = new JLabel("Player");
		lblPlayerImg.setBounds(20, 30, 320, 490);
		PlayScr.add(lblPlayerImg);
		
		//Monster image in play screen
		JLabel lblMonsterImg = new JLabel("Monster");
		lblMonsterImg.setBounds(350, 30, 320, 490);
		PlayScr.add(lblMonsterImg);
		
				
		//Character health info in inventory
		JLabel lblHP = new JLabel("Character HP");
		lblHP.setForeground(new Color(255, 0, 255));
		lblHP.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHP.setBounds(358, 383, 253, 38);
		Inventory.add(lblHP);
		
		//Character Attack Power info in inventory
		JLabel lblAttack = new JLabel("Character AP");
		lblAttack.setForeground(new Color(255, 0, 255));
		lblAttack.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAttack.setBounds(358, 285, 253, 38);
		Inventory.add(lblAttack);
		
		//Character Armor info in inventory
		JLabel lblArmor = new JLabel("Character DP");
		lblArmor.setForeground(new Color(255, 0, 255));
		lblArmor.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblArmor.setBounds(358, 334, 253, 38);
		Inventory.add(lblArmor);
		
		//Player's gold info in inventory
		JLabel lblCharGold = new JLabel("Character Gold");
		lblCharGold.setForeground(new Color(255, 255, 0));
		lblCharGold.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCharGold.setBounds(358, 432, 253, 38);
		Inventory.add(lblCharGold);
		
		//Labels for the images of item
		JLabel lblAttItem = new JLabel("Attack Item Image");
		lblAttItem.setIcon(new ImageIcon(MainFrame.class.getResource("/img/attack.jpg")));
		lblAttItem.setBounds(684, 65, 150, 110);
		Inventory.add(lblAttItem);
		
		JLabel lblDefItem = new JLabel("Defense Item Image");
		lblDefItem.setIcon(new ImageIcon(MainFrame.class.getResource("/img/defense.jpg")));
		lblDefItem.setBounds(684, 212, 150, 110);
		Inventory.add(lblDefItem);
		
		JLabel lblHealthItem = new JLabel("Health Item Image");
		lblHealthItem.setIcon(new ImageIcon(MainFrame.class.getResource("/img/helth.jpg")));
		lblHealthItem.setBounds(684, 360, 150, 110);
		Inventory.add(lblHealthItem);
		
		//Items information in Inventory	
		JLabel lblChAp = new JLabel("Changed AP");
		lblChAp.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblChAp.setForeground(new Color(255, 140, 0));
		lblChAp.setBounds(358, 37, 306, 54);
		Inventory.add(lblChAp);
		
		JLabel lblChDp = new JLabel("Changed DP");
		lblChDp.setForeground(new Color(255, 140, 0));
		lblChDp.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblChDp.setBounds(358, 102, 306, 54);
		Inventory.add(lblChDp);
		
		JLabel lblChHp = new JLabel("Changed HP");
		lblChHp.setForeground(new Color(255, 140, 0));
		lblChHp.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblChHp.setBounds(358, 167, 306, 54);
		Inventory.add(lblChHp);
		
		//Character Image for in Inventory
		JLabel lblCharacterImg = new JLabel("Character Image");
		lblCharacterImg.setBounds(28, 37, 320, 490);
		Inventory.add(lblCharacterImg);
		
		//ComboBox for selecting player character in character setting screen
		JComboBox cbSelectChar = new JComboBox();
		cbSelectChar.setForeground(new Color(255, 255, 255));
		cbSelectChar.setBackground(new Color(85, 107, 47));
		cbSelectChar.setBounds(192, 438, 142, 22);
		CharSet.add(cbSelectChar);
		
		//Play Button (Start Game) in Character Setting Screen		
		JButton toPlayScr = new JButton("Play");
		toPlayScr.setEnabled(false);
		toPlayScr.setForeground(Color.WHITE);
		toPlayScr.setFont(new Font("Tahoma", Font.BOLD, 14));
		toPlayScr.setBackground(new Color(85, 107, 47));
		toPlayScr.setBounds(802, 430, 111, 38);
		CharSet.add(toPlayScr);
		
		//Quit button to go to start screen from Character Setting Screen	
		JButton goToStart = new JButton("Quit Game");
		goToStart.setForeground(Color.WHITE);
		goToStart.setFont(new Font("Tahoma", Font.BOLD, 14));
		goToStart.setBackground(new Color(102, 51, 51));
		goToStart.setBounds(802, 489, 111, 38);
		CharSet.add(goToStart);
		
		JTextArea txtrBattleInfo = new JTextArea();
		txtrBattleInfo.setFont(new Font("Monospaced", Font.BOLD, 13));
		txtrBattleInfo.setBackground(SystemColor.textInactiveText);
		txtrBattleInfo.setForeground(new Color(255, 215, 0));
		txtrBattleInfo.setText("Battle status information");
		txtrBattleInfo.setBounds(681, 72, 235, 90);
		PlayScr.add(txtrBattleInfo);
		
		//Attack Button
		JButton btnAttack = new JButton("Attack");
		btnAttack.setForeground(Color.WHITE);
		btnAttack.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAttack.setBackground(new Color(255, 0, 0));
		btnAttack.setBounds(805, 191, 111, 38);
		PlayScr.add(btnAttack);
		
		//Button to go to Inventory screen
		JButton goToInventory = new JButton("Inventory");
		goToInventory.setForeground(Color.WHITE);
		goToInventory.setFont(new Font("Tahoma", Font.BOLD, 14));
		goToInventory.setBackground(new Color(47, 79, 79));
		goToInventory.setActionCommand("StartGame");
		goToInventory.setBounds(813, 407, 111, 38);
		PlayScr.add(goToInventory);
		
		//Continue button 
		JButton btnContGame = new JButton("Continue");
		btnContGame.setEnabled(false);
		btnContGame.setForeground(Color.WHITE);
		btnContGame.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnContGame.setBackground(new Color(25, 25, 112));
		btnContGame.setActionCommand("StartGame");
		btnContGame.setBounds(813, 456, 111, 38);
		PlayScr.add(btnContGame);
		
		//Quit button to go to start screen from play screen
		JButton quitGame = new JButton("Quit Game");
		quitGame.setForeground(Color.WHITE);
		quitGame.setFont(new Font("Tahoma", Font.BOLD, 14));
		quitGame.setBackground(new Color(102, 51, 51));
		quitGame.setActionCommand("StartGame");
		quitGame.setBounds(813, 502, 111, 38);
		PlayScr.add(quitGame);
		
		//CheckBoxs to select Item in Inventory
		JCheckBox chckbxAttack = new JCheckBox("10 Gold: Strengthen AP");
		chckbxAttack.setEnabled(false);
		chckbxAttack.setBackground(new Color(47, 79, 79));
		chckbxAttack.setForeground(new Color(220, 20, 60));
		chckbxAttack.setFont(new Font("Tahoma", Font.BOLD, 12));
		chckbxAttack.setBounds(670, 38, 200, 20);
		Inventory.add(chckbxAttack);		
		
		JCheckBox chckbxDefense = new JCheckBox("15 Gold: Strengthen DP");
		chckbxDefense.setEnabled(false);
		chckbxDefense.setForeground(new Color(255, 215, 0));
		chckbxDefense.setBounds(670, 185, 200, 20);
		chckbxDefense.setBackground(new Color(47, 79, 79));
		chckbxDefense.setFont(new Font("Tahoma", Font.BOLD, 12));
		Inventory.add(chckbxDefense);
		
		JCheckBox chckbxHealth = new JCheckBox("20 Gold: Strengthen HP");
		chckbxHealth.setEnabled(false);
		chckbxHealth.setFont(new Font("Tahoma", Font.BOLD, 12));
		chckbxHealth.setForeground(new Color(0, 250, 154));
		chckbxHealth.setBackground(new Color(47, 79, 79));
		chckbxHealth.setBounds(670, 333, 200, 20);
		Inventory.add(chckbxHealth);
				
		//Labels for character information in character setting screen
		JLabel lblCharTitle = new JLabel("Select Character");
		lblCharTitle.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 16));
		lblCharTitle.setForeground(new Color(255, 69, 0));
		lblCharTitle.setBounds(463, 36, 178, 38);
		CharSet.add(lblCharTitle);
		
		JLabel lblCharHInfo = new JLabel("Character Health");
		lblCharHInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCharHInfo.setForeground(new Color(255, 69, 0));
		lblCharHInfo.setBounds(192, 156, 253, 38);
		CharSet.add(lblCharHInfo);
		
		JLabel lblCharAttPw = new JLabel("Character Attack");
		lblCharAttPw.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCharAttPw.setForeground(new Color(255, 69, 0));
		lblCharAttPw.setBounds(192, 205, 253, 38);
		CharSet.add(lblCharAttPw);
		
		JLabel lblCharArmor = new JLabel("Character Defense");
		lblCharArmor.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCharArmor.setForeground(new Color(255, 69, 0));
		lblCharArmor.setBounds(192, 254, 253, 38);
		CharSet.add(lblCharArmor);
		
		//Label for character image in character setting screen
		JLabel lblCharaterImg = new JLabel("Character Image");
		lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Archer.jpg")));
		lblCharaterImg.setBounds(455, 36, 320, 490);
		CharSet.add(lblCharaterImg);
	
		//Labels for Main screen background image
		JLabel lblMainBGI = new JLabel("main background image");
		lblMainBGI.setIcon(new ImageIcon(MainFrame.class.getResource("/img/mainBackground.jpg")));
		lblMainBGI.setBounds(0, 0, 934, 551);
		StartScr.add(lblMainBGI);
		
		//Labels for character screen background image
		JLabel lblCharacterScrBGI = new JLabel("character screen background");
		lblCharacterScrBGI.setIcon(new ImageIcon(MainFrame.class.getResource("/img/charScrBackground.jpg")));
		lblCharacterScrBGI.setBounds(0, 0, 934, 551);
		CharSet.add(lblCharacterScrBGI);
		
		//Purchase Item button in Inventory 
		JButton purchaseItem = new JButton("Purchase");
		purchaseItem.setEnabled(false);
		purchaseItem.setBackground(new Color(70, 130, 180));
		purchaseItem.setForeground(Color.WHITE);
		purchaseItem.setFont(new Font("Tahoma", Font.BOLD, 14));
		purchaseItem.setBounds(656, 489, 111, 38);
		Inventory.add(purchaseItem);
		
		//Back Button to move to character setting screen	
		JButton backToPlayScreen = new JButton("Previous");
		backToPlayScreen.setForeground(Color.WHITE);
		backToPlayScreen.setFont(new Font("Tahoma", Font.BOLD, 14));
		backToPlayScreen.setBackground(new Color(160, 82, 45));
		backToPlayScreen.setActionCommand("StartGame");
		backToPlayScreen.setBounds(777, 489, 111, 38);
		Inventory.add(backToPlayScreen);
		
		//Labels for inventory screen background image
		JLabel lblInvenBGI = new JLabel("Inventory background");
		lblInvenBGI.setIcon(new ImageIcon(MainFrame.class.getResource("/img/inventory.jpg")));
		lblInvenBGI.setBounds(0, 0, 934, 551);
		Inventory.add(lblInvenBGI);
		
		//Labels for Play screen background image
		JLabel lblPlayScrBGI = new JLabel("Play screen background image");
		lblPlayScrBGI.setForeground(new Color(255, 255, 0));
		lblPlayScrBGI.setIcon(new ImageIcon(MainFrame.class.getResource("/img/dungeon.jpg")));
		lblPlayScrBGI.setBounds(0, 0, 934, 551);
		PlayScr.add(lblPlayScrBGI);
		
		
		/**** Action Listeners ****/
					
		//Start Button Action Listener in Main		
		Start.setActionCommand("StartGame");
		Start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				StartScr.setVisible(false);
				CharSet.setVisible(true);
				}
		});
		
		//Exit Button in Main
		exit.setActionCommand("StartGame");
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				System.exit(0);
			}
		});
		

		//Play Button (Start Game) Action Listener in Character Setting Screen		
		toPlayScr.setActionCommand("StartGame");
		toPlayScr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){	
				
				//Setting values for random selected Monsters
				int RandomMonID = (int)(Math.random()*3+1);
				if(RandomMonID == 1) {			
					Monster.setMonsterID(1);
					Monster.setName("Hell_Knight");
					Monster.setHp(30);
					Monster.setAttack(10);
					Monster.setDeffense(4);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}
				else if(RandomMonID == 2) {
					Monster.setMonsterID(2);
					Monster.setName("Grim_Reaper");
					Monster.setHp(40);
					Monster.setAttack(11);
					Monster.setDeffense(3);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}
				else if(RandomMonID == 3) {
					Monster.setMonsterID(3);
					Monster.setName("Demogorgon");
					Monster.setHp(50);
					Monster.setAttack(12);
					Monster.setDeffense(5);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}				
				
				//Setting values for Selected Character
				if(selectedType == 1) {//Archer
					//setting character
					Player.setCharType(1);
					Player.setName("Archer");
					Player.setHp(25);
					Player.setAttack(10);
					Player.setDeffense(5);
					//Player.setGold(0);
					Player.setGold(40); //test for gold
					Player.setItems(0,1,2);
					//setting display information
					lblPlayerImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Player.getName()+".jpg")));
					lblCharName.setText(Player.getName());
					lblPlayerHP.setText("HP: "+Player.getHp());
					lblPlayerattack.setText("AP: "+Player.getAttack());
					lblPlayerDefense.setText("DP: "+Player.getDeffense());
					lblGold.setText("Gold: "+Player.getGold());
				}
				else if(selectedType == 2) {//Swordsman
					Player.setCharType(2);
					Player.setName("Swordsman");
					Player.setHp(45);
					Player.setAttack(6);
					Player.setDeffense(6);
					Player.setGold(0);
					Player.setItems(0,1,2);
					lblPlayerImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Player.getName()+".jpg")));
					lblCharName.setText(Player.getName());
					lblPlayerHP.setText("HP: "+Player.getHp());
					lblPlayerattack.setText("AP: "+Player.getAttack());
					lblPlayerDefense.setText("DP: "+Player.getDeffense());
					lblGold.setText("Gold: "+Player.getGold());
				}
				else if(selectedType == 3) {//Spearman
					Player.setCharType(3);
					Player.setName("Spearman");
					Player.setHp(30);
					Player.setAttack(8);
					Player.setDeffense(6);
					Player.setGold(0);
					Player.setItems(0,1,2);
					lblPlayerImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Player.getName()+".jpg")));
					lblCharName.setText(Player.getName());
					lblPlayerHP.setText("HP: "+Player.getHp());
					lblPlayerattack.setText("AP: "+Player.getAttack());
					lblPlayerDefense.setText("DP: "+Player.getDeffense());
					lblGold.setText("Gold: "+Player.getGold());
				}
				
				//Inventory button lock for no gold
				if(Player.getGold()<10)
					goToInventory.setEnabled(false);
				else
					goToInventory.setEnabled(true);

				//Screen Change
				//txtrBattleInfo.setText(playAttack.getCombatInfo());
				txtrBattleInfo.setText("Battle Information");
				CharSet.setVisible(false);
				PlayScr.setVisible(true);
				
			}
		});
		
		
		//ComboBox process in character setting screen
		cbSelectChar.setModel(new DefaultComboBoxModel(new String[] {"Select Character", "Archer", "Swordsman", "Spearman"}));
		cbSelectChar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				if(cbSelectChar.getSelectedIndex() == 1) {
					lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Archer.jpg")));
					lblCharTitle.setText("Archer");
					lblCharHInfo.setText("Archer's Heath: 25");
					lblCharAttPw.setText("Archer's Attack: 10");
					lblCharArmor.setText("Archer's Defense: 5");
					selectedType = 1;
				}
				else if(cbSelectChar.getSelectedIndex() == 2) {
					lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Swordsman.jpg")));
					lblCharTitle.setText("Swordsman");
					lblCharHInfo.setText("Swordsman's Heath: 45");
					lblCharAttPw.setText("Swordsman's Attack: 6");
					lblCharArmor.setText("ASwordsman's Defense: 6");
					selectedType = 2;
				}
				else if(cbSelectChar.getSelectedIndex() == 3) {
					lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Spearman.jpg")));
					lblCharTitle.setText("Spearman");
					lblCharHInfo.setText("Spearman's Heath: 30");
					lblCharAttPw.setText("Spearman's Attack: 8");
					lblCharArmor.setText("Spearman's Defense: 6");
					selectedType = 3;
				}
				toPlayScr.setEnabled(true);
			}
		});
		
		
		//Quit button Action Listener to go to start screen from Character Setting Screen	
		goToStart.setActionCommand("MoveToStartScreen");
		goToStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				CharSet.setVisible(false);
				StartScr.setVisible(true);
				lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Archer.jpg")));
				cbSelectChar.setSelectedIndex(0);
				lblCharTitle.setText("Select Character");
				lblCharHInfo.setText("Character Heath");
				lblCharAttPw.setText("Character Attack");
				lblCharArmor.setText("Character Defense");
				selectedType = 0;
				}
		});
		
		//CheckBoxs Action Listeners
		chckbxAttack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				
				if(chckbxAttack.isSelected() == true)
				{
					lblChAp.setText("Increse Current AP "+Player.getAttack()+" + 3!");
					purchaseItem.setEnabled(true);
					Player.setGold(Player.getGold()-10);
					lblCharGold.setText("Gold: "+Player.getGold());
					
					if(Player.getGold() < 15 && chckbxDefense.isSelected() == false) {
						chckbxDefense.setEnabled(false);
					}
					if(Player.getGold() < 15 && chckbxHealth.isSelected() == false) {
						chckbxHealth.setEnabled(false);
					}
					if(Player.getGold() < 20 && chckbxHealth.isSelected() == false) {
						chckbxHealth.setEnabled(false);
					}
				}
				else 
				{
					lblChAp.setText("Changed AP");
					Player.setGold(Player.getGold()+10);
					lblCharGold.setText("Gold: "+Player.getGold());
					
						if(Player.getGold() >= 15 && Player.getGold() < 20) {
							if(Player.getItems(1) == false)
								chckbxDefense.setEnabled(true);			
						}
						if(Player.getGold() >= 20) {
							if(Player.getItems(1) == false)
								chckbxDefense.setEnabled(true);
							if(Player.getItems(2) == false)
								chckbxHealth.setEnabled(true);
						}
						if(chckbxDefense.isSelected() == false && chckbxHealth.isSelected() == false) {
							purchaseItem.setEnabled(false);
						}
				}
			}
		});
		

		chckbxDefense.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){

			if(chckbxDefense.isSelected() == true)
			{
				lblChDp.setText("Increse Current DP "+Player.getDeffense()+" + 3!");
				purchaseItem.setEnabled(true);
				Player.setGold(Player.getGold()-15);
				lblCharGold.setText("Gold: "+Player.getGold());

				if(Player.getGold() < 10 && chckbxAttack.isSelected() == false) {
					chckbxAttack.setEnabled(false);
				}
				if(Player.getGold() < 20 && chckbxHealth.isSelected() == false) {
					chckbxHealth.setEnabled(false);
				}
				if(Player.getGold() > 10 && Player.getGold() < 20) {
					if(Player.getItems(0) == false)
						chckbxAttack.setEnabled(true);
				}
			}
			else 
			{
				lblChDp.setText("Changed DP");
				Player.setGold(Player.getGold()+15);
				lblCharGold.setText("Gold: "+Player.getGold());
				
					if(Player.getGold() < 20) {
						if(Player.getItems(0) == false)
							chckbxAttack.setEnabled(true);			
					}
					if(Player.getGold() >= 20) {
						if(Player.getItems(0) == false)
							chckbxAttack.setEnabled(true);
						if(Player.getItems(2) == false)
							chckbxHealth.setEnabled(true);
					}
					if(chckbxAttack.isSelected() == false && chckbxHealth.isSelected() == false) {
						purchaseItem.setEnabled(false);
					}
				}
			}
		});

		chckbxHealth.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){

			if(chckbxHealth.isSelected() == true)
			{
				lblChHp.setText("Increse Current HP "+Player.getHp()+" + 3!");
				purchaseItem.setEnabled(true);
				Player.setGold(Player.getGold()-20);
				lblCharGold.setText("Gold: "+Player.getGold());
								
				if(Player.getGold() < 10 && chckbxAttack.isSelected() == false) {
					chckbxAttack.setEnabled(false);
				}
				if(Player.getGold() < 10 && chckbxDefense.isSelected() == false) {
					chckbxDefense.setEnabled(false);
				}
				if(Player.getGold() < 15 && chckbxDefense.isSelected() == false)
					chckbxDefense.setEnabled(false);
			}
			else 
			{
				lblChHp.setText("Changed HP");
				Player.setGold(Player.getGold()+20);
				lblCharGold.setText("Gold: "+Player.getGold());

				if(Player.getItems(0) == false)
					chckbxAttack.setEnabled(true);
				if(Player.getItems(1) == false)
					chckbxDefense.setEnabled(true);
				
				if(chckbxAttack.isSelected() == false && chckbxHealth.isSelected() == false) {
					purchaseItem.setEnabled(false);
				}
			}
		}
		});
		
		
		//Purchase Item button Action Listener in Inventory 

		purchaseItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){

				if(chckbxAttack.isSelected() == true && Player.getItems(0) == false)
				{
					Player.setItems(0, true);
					Player.setAttack(Player.getAttack()+3);
					chckbxAttack.setEnabled(false);
					lblAttack.setText("Current AP: "+Player.getAttack()+" (Basic AP + 3)");
					if((Player.getItems(0)&&Player.getItems(1)&&Player.getItems(2))||Player.getGold()<=10)
						purchaseItem.setEnabled(false);	
				}
				
				if(chckbxDefense.isSelected() == true && Player.getItems(1) == false)
				{
					Player.setItems(1, true);
					Player.setDeffense(Player.getDeffense()+3);
					chckbxDefense.setEnabled(false);
					lblArmor.setText("Current DP: "+Player.getDeffense()+" (Basic DP + 3)");
					if((Player.getItems(0)&&Player.getItems(1)&&Player.getItems(2))||Player.getGold()<=10)
						purchaseItem.setEnabled(false);	
				}	
				
				if(chckbxHealth.isSelected() == true && Player.getItems(2) == false)
				{
					Player.setItems(2, true);
					Player.setHp(Player.getHp()+3);
					chckbxHealth.setEnabled(false);
					lblHP.setText("Current HP: "+Player.getHp()+" (Basic HP + 3)");
					if((Player.getItems(0)&&Player.getItems(1)&&Player.getItems(2))||Player.getGold()<=10)
						purchaseItem.setEnabled(false);	
				}
				lblCharGold.setText("Gold: "+Player.getGold());
			}
		});

	
		//Back Button Action Listener to move to Play screen from inventory	
		backToPlayScreen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				
				lblPlayerHP.setText("HP: "+Player.getHp());
				lblPlayerattack.setText("AP: "+Player.getAttack());
				lblPlayerDefense.setText("DP: "+Player.getDeffense());
				lblGold.setText("Gold: "+Player.getGold());
				
				Inventory.setVisible(false);
				PlayScr.setVisible(true);
				}
		});
		
		//Inventory Button Action Listener go to inventory from Play Screen
		goToInventory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				//Display player information in Inventory Screen
				if(Player.getItems(0)==true) 
					lblAttack.setText("Current AP: "+Player.getAttack()+" (Basic AP + 3)");
				else 
					lblAttack.setText("Current AP: "+Player.getAttack());

				if(Player.getItems(1)==true) 
					lblArmor.setText("Current DP: "+Player.getDeffense()+" (Basic DP + 3)");
				else
					lblArmor.setText("Current DP: "+Player.getDeffense());
					
				if(Player.getItems(2)==true)
					lblHP.setText("Current HP: "+Player.getHp()+" (Basic HP + 3)");
				else
					lblHP.setText("Current HP: "+Player.getHp());

				lblCharGold.setText("Gold: "+Player.getGold());
				lblCharacterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Player.getName()+".jpg")));
				
				//change screen
				Inventory.setVisible(true);
				PlayScr.setVisible(false);
				
				//button control
				if(Player.getGold() > 9 && Player.getItems(0) == false)
					chckbxAttack.setEnabled(true);
				if(Player.getGold() > 14 && Player.getItems(1) == false)
					chckbxDefense.setEnabled(true);
				if(Player.getGold() > 19 && Player.getItems(2) == false)
					chckbxHealth.setEnabled(true);
				}
		});
		
		//Attack button Action Listener to play game
		btnAttack.setActionCommand("Attack");
		btnAttack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				
				quitGame.setEnabled(false);
				goToInventory.setEnabled(false);


				playAttack.setAttackSuccess(playAttack.attackResult());//Try to attack by dice game with the number witch made by Mesh.random
			
				//return the result of dice game
				if(playAttack.isAttackSuccess() == true) {//Player attack success
					playAttack.setCombatInfo("Your attack success!!\nMonster's damage:\nMonster DP("+Monster.getDeffense()+") - Player AP("+Player.getAttack()+")\n = "+(Player.getAttack()-Monster.getDeffense()));
					txtrBattleInfo.setText(playAttack.getCombatInfo());
					Monster.setHp((Monster.getHp()-(Player.getAttack()-Monster.getDeffense())));
					
					if(Monster.getHp()<0)
						Monster.setHp(0);
					
					lblMonsterHp.setText("HP: "+Monster.getHp());

				}
				else//Monster attack success
				{
					playAttack.setCombatInfo("Monster Defense success!!\nPlayer's damage:\nPlayer DP("+Player.getDeffense()+") - Monster AP("+Monster.getAttack()+")\n = "+(Monster.getAttack()-Player.getDeffense()));
					txtrBattleInfo.setText(playAttack.getCombatInfo());
					Player.setHp((Player.getHp()-(Monster.getAttack()-Player.getDeffense())));
					
					if(Player.getHp()<0)
						Player.setHp(0);
					
					lblPlayerHP.setText("HP: "+Player.getHp());
				}

				
				if(Player.getHp() <= 0 || Monster.getHp() <= 0){//Player Win
					if(Player.getHp() > Monster.getHp()) {
						txtrBattleInfo.setText("Victory~!!! \nYou can receive 5 gold!!\nOh my hero~~\nPlease defeat \ndemons continuously....");
						Player.setGold(Player.getGold()+5);
					}
					else{//Monster Win
						txtrBattleInfo.setText("Oh...my god...\n Monster Win....");
						Player.setGold(Player.getGold()-2);
						
						if(Player.getGold()<0)
							Player.setGold(0);					
					}
					
					lblGold.setText("Gold: "+Player.getGold());
					btnContGame.setEnabled(true);
					quitGame.setEnabled(true);
					btnAttack.setEnabled(false);
			
				}
				
			}
		});
		
		//Continue button Action Listener to play again with random enemy
		btnContGame.setActionCommand("continueGame");
		btnContGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
			
				//Inventory button lock for no gold
				if(Player.getGold()<10)
				goToInventory.setEnabled(false);
				
				//Re-Setting random Monsters
				int RdmMonID = (int)(Math.random()*3+1);
				if(RdmMonID == 1) {			
					Monster.setMonsterID(1);
					Monster.setName("Hell_Knight");
					Monster.setHp(30);
					Monster.setAttack(10);
					Monster.setDeffense(3);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}
				else if(RdmMonID == 2) {
					Monster.setMonsterID(2);
					Monster.setName("Grim_Reaper");
					Monster.setHp(40);
					Monster.setAttack(11);
					Monster.setDeffense(4);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}
				else if(RdmMonID == 3) {
					Monster.setMonsterID(3);
					Monster.setName("Demogorgon");
					Monster.setHp(50);
					Monster.setAttack(12);
					Monster.setDeffense(5);
					lblMonsterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/"+Monster.getName()+".jpg")));
					lblMonName.setText(Monster.getName());
					lblMonsterHp.setText("HP: "+Monster.getHp());
					lblMonstgerAttack.setText("AP: "+Monster.getAttack());
					lalMonsterDeffense.setText("DP: "+Monster.getDeffense());
				}
				
				//Re-Setting HP value of player for next stage
				if(Player.getCharType() == 1) {//Archer
					if(Player.getItems(2) == true)
						Player.setHp(25+5);
					else
						Player.setHp(25);
					}
				
				if(Player.getCharType() == 2) {//Swordsman
					if(Player.getItems(2) == true)
						Player.setHp(45+5);
					else
						Player.setHp(45);
					}
					
				if(Player.getCharType() == 3) {//Spearman
					if(Player.getItems(2) == true)
						Player.setHp(30+5);
					else
						Player.setHp(30);
					}
										
					//Display Re-setting Information
					lblPlayerHP.setText("HP: "+Player.getHp());
					lblGold.setText("Gold: "+Player.getGold());
					txtrBattleInfo.setText("Battle Information");

					//Continue button disable
					btnContGame.setEnabled(false);
					btnAttack.setEnabled(true);
					if(Player.getGold()>=10)
						goToInventory.setEnabled(true);
			}
		});
		
		//Quit button Action Listener to go to start screen from play screen
		quitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
		
				//Reset
				lblCharaterImg.setIcon(new ImageIcon(MainFrame.class.getResource("/img/Archer.jpg")));
				cbSelectChar.setSelectedIndex(0);
				lblCharTitle.setText("Select Character");
				lblCharHInfo.setText("Character Heath");
				lblCharAttPw.setText("Character Attack");
				lblCharArmor.setText("Character Armor");

				chckbxAttack.setSelected(false);
				chckbxDefense.setSelected(false);
				chckbxHealth.setSelected(false);
				
				selectedType = 0;
				
				toPlayScr.setEnabled(false);
				btnAttack.setEnabled(true);
				goToInventory.setEnabled(false);
				btnContGame.setEnabled(false);
				
				PlayScr.setVisible(false);
				StartScr.setVisible(true);
				}
		});
		
			

	}
}
