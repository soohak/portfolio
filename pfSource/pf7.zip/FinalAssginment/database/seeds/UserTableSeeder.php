<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Role;


class UserTableSeeder extends Seeder
{

    public function run()
    {
        $role_user_administrator = Role::where('name', 'User Administrator')->first();
        $role_theme_manager = Role::where('name', 'Theme Manager')->first();
        $role_post_moderator = Role::where('name', 'Post Moderator')->first();
        $role_common_user = Role::where('name', 'User')->first();

        $user_administrator = new User();
        $user_administrator->name = 'Soohak';
        $user_administrator->email = 'soohak@sample.com';
        $user_administrator->password = bcrypt('nsccksh');
        $user_administrator->save();
        $user_administrator->roles()->attach($role_user_administrator);

        $theme_manager = new User();
        $theme_manager->name = 'Soohagi';
        $theme_manager->email = 'theme_guy@example.com';
        $theme_manager->password = bcrypt('nsccksh');
        $theme_manager->save();
        $theme_manager->roles()->attach($role_theme_manager);

        $post_moderator = new User();
        $post_moderator->name = 'Michael Soohak KIM';
        $post_moderator->email = 'post_manager@sample.com';
        $post_moderator->password = bcrypt('nsccksh');
        $post_moderator->save();
        $post_moderator->roles()->attach($role_post_moderator);

        $common_user = new User();
        $common_user->name = 'Tester1';
        $common_user->email = 'test1@sample.com';
        $common_user->password = bcrypt('nsccksh');
        $common_user->save();
        $common_user->roles()->attach($role_common_user);
    }
}
