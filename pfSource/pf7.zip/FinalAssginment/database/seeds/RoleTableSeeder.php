<?php

use Illuminate\Database\Seeder;
use App\Role;


class RoleTableSeeder extends Seeder
{

    public function run()
    {

        $role_user_administrator = new Role();
        $role_user_administrator->name = 'User Administrator';
        $role_user_administrator->description = 'A manager for the User Information';
        $role_user_administrator->save();

        $role_theme_manager = new Role();
        $role_theme_manager->name = 'Theme Manager';
        $role_theme_manager->description = 'A manager for the Themes';
        $role_theme_manager->save();

        $role_post_moderator = new Role();
        $role_post_moderator->name = 'Post Moderator';
        $role_post_moderator->description = 'A manager for the Posts';
        $role_post_moderator->save();

        $role_common_user = new Role();
        $role_common_user->name = 'User';
        $role_common_user->description = 'Common User';
        $role_common_user->save();

    }
}
