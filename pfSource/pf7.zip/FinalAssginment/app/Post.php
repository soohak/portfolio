<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;


class Post extends Model
{

    use SoftDeletes;

    protected $dates = ['delete_at'];

    protected $fillable = [

        'title', 'body', 'link',

    ];

    public function user(Post $post) //return user name with created_id
    {

        $user_id = $post->created_by;

        $user = User::find($user_id);

        return $user->name;

    }

    public function updateUser(Post $post) //return user name with last_updated_by
    {

        $user_id = $post->last_updated_by;

        $user = User::find($user_id);

        if($user)
            return $user->name;

        return 'Non';

    }

}
