<?php

namespace App\Http\Middleware;

use Closure;


class CheckIsPostModerator
{

    public function handle($request, Closure $next)
    {

        if (! $request->user()->hasRole('Post Moderator')) {

            session()->flash('message', 'Sorry, you are not Post Moderator.');

            return redirect('/');

        }

        return $next($request);
    }

}
