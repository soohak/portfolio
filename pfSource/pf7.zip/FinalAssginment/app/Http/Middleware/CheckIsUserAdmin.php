<?php

namespace App\Http\Middleware;

use Closure;


class CheckIsUserAdmin
{


    public function handle($request, Closure $next)
    {

        if (! $request->user()->hasRole('User Administrator')) {

            session()->flash('message', 'Sorry, you are not User Administrator.');

            return redirect('/');

        }

        return $next($request);

    }
}
