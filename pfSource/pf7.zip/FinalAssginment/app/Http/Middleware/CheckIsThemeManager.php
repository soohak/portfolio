<?php

namespace App\Http\Middleware;

use Closure;


class CheckIsThemeManager
{

    public function handle($request, Closure $next)
    {

        if (! $request->user()->hasRole('Theme Manager')) {

            session()->flash('message', 'Sorry, you are not Theme Manager.');

            return redirect('/');

        }

        return $next($request);
    }

}
