<?php

namespace App\Http\Controllers;

use App\Theme;

use Illuminate\Http\Request;

class ThemeController extends Controller
{
    // Show the table of theme in theme management
    public function index()
    {

        $themes = Theme::all();

        return view('themes.index', compact('themes'));

    }

    // Show detail theme
    public function show(Theme $theme)
    {

        return view('themes.show', compact('theme'));

    }

    // Create new theme
    public function create()    // show the theme form
    {

        return view('themes.create');

    }

    public function store(Request $request) // store the new theme
    {
        $this->validate(request(), [

            'name' => 'required',

            'description' => 'required',

            'cdn_url' => 'required'

        ]);

        $theme = new Theme;


        $theme->name = $request->name;

        $theme->description = $request->description;

        $theme->cdn_url = $request->cdn_url;


        if($request->has('isDefault'))
        {
            //current default theme's set to non default
            Theme::query()->update(array('is_default' => 0));

            //set default for new theme
            $theme->is_default = 1;

        }
        else
        $theme->is_default = 0;


        $theme->created_by = auth()->user()->id;

        $theme->save();


        $themes = Theme::all();

        return view('themes.index', compact('themes'));
    }

    // Update Theme
    public function edit(Theme $theme)
    {

        return view('themes.edit', compact('theme'));

    }

    public function update(Request $request, Theme $theme)
    {
        $this->validate(request(), [

            'name' => 'required',

            'description' => 'required',

            'cdn_url' => 'required'

        ]);

        $theme->name = $request->name;

        $theme->description = $request->description;

        $theme->cdn_url = $request->cdn_url;


        if($request->has('isDefault'))
        {
            //current default theme's set to non default
            Theme::query()->update(array('is_default' => 0));

            //set default for new theme
            $theme->is_default = 1;

        }
        else
            $theme->is_default = 0;


        $theme->last_updated_by = auth()->user()->id;

        $theme->save();


        $themes = Theme::all();

        return view('themes.index', compact('themes'));
    }

    // Delete theme (not soft)
    public function destroy(Theme $theme)
    {
        if($theme->is_default ===1)
        {
            $basic_theme = Theme::find(1);
            $basic_theme->is_default = 1;
            $basic_theme->save();
        }

        $theme->delete();


        $themes = Theme::all();

        return view('themes.index', compact('themes'));
    }

}
