<?php

namespace App\Http\Controllers;

use App\Post;

use App\Theme;

use Illuminate\Http\Request;


class PostController extends Controller
{
    // Show the all posts
    public function index()
    {
//        $posts = Post::all();
        $posts = Post::latest()->get();

        return view('posts.index', compact('posts'));
    }

    // Show the table of post in post management
    public function exists()
    {

        $posts = Post::all();

        return view('posts.table', compact('posts'));

    }

    // Show the one post when title is clicked by
    public function show(Post $post)
    {

        return view('posts.individual', compact('post'));

    }

    // Show the post form
    public function create()
    {

        return view('posts.create');

    }

    // Store new post
    public function store(Request $request)
    {

        $this->validate(request(), [

            'title' => 'required',

            'body' => 'required',

            'link' => 'required'

        ]);

        $post = new Post;

        $post->title = $request->title;

        $post->body = $request->body;

        $post->link = $request->link;

        $post->created_by = auth()->user()->id;

        $post->save();

        $posts = Post::all();

        return view('posts.index', compact('posts'));

    }

    // Update
    public function edit(Post $post)// show the post form for updating
    {

        return view('posts.edit', compact('post'));

    }

    public function update(Request $request, Post $post) //store modified post
    {

        $this->validate(request(), [

            'title' => 'required',

            'body' => 'required',

            'link' => 'required',

        ]);

        $post->title = $request->title;

        $post->body = $request->body;

        $post->link = $request->link;

        $post->last_updated_by = auth()->user()->id;

        //store the modified info to db
        $post->save();


        $posts = Post::all();

        return view('posts.table', compact('posts'));

    }

    // Soft Deleting
    public function destroy(Post $post)
    {
        $post->deleted_by = auth()->user()->id;

        $post->save();

        $post->delete();

        $posts = Post::all();

        return view('posts.table', compact('posts'));
    }

}
