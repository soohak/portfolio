<?php

namespace App\Http\Controllers;

use App\User;

use App\Role;

use Illuminate\Http\Request;



class UserController extends Controller
{

    // show all users information
    public function index()
    {

        $users = User::all();

        return view('users.index', compact('users'));

    }


    // Searching the user by search word
    public function search(Request $request)
    {

        $users = User::search($request->search)->get();

        return view('users.index', compact('users'));

    }


    // Modification user information and role
    public function edit(User $user)
    {
        return view('users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $this->validate(request(), [

            'name' => 'required',

            'email' => 'required'

        ]);

        //modify user name
        $user->name =$request->name;

        //modify user email
        $user->email =$request->email;

        //check the roles and set up

        $user->roles()->detach(); //Detach all roles

        if($request->has('userMng'))
            $user->roles()->attach(Role::where('name', 'User Administrator')->first());

        if($request->has('themeMng'))
            $user->roles()->attach(Role::where('name', 'Theme Manager')->first());

        if($request->has('postMng'))
            $user->roles()->attach(Role::where('name', 'Post Moderator')->first());

        $user->last_updated_by = auth()->user()->id;

        //store the modified info to db
        $user->save();

        $users = User::all();
        return view('users.index', compact('users'));

    }


    // Delete user by soft deleting
    public function destroy(User $user)
    {

        $user->deleted_by = auth()->user()->id;

        $user->save();

        $user->delete();

        $users = User::all();

        return view('users.index', compact('users'));

    }


    // Show the users who deleted by soft deleting
    public function trash()
    {

        $users = User::onlyTrashed()->get();

        return view('users.trash', compact('users'));

    }

    // Restore the users who deleted by soft deleting
    public function restore($id)
    {

        $user = User::onlyTrashed()->find($id);

        $user->restore();

        $users = User::onlyTrashed()->get();
        return view('users.trash', compact('users'));

    }

}
