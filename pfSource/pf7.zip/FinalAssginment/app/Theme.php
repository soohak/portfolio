<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Theme extends Model
{

    protected $fillable = [

        'name', 'cdn_url', 'description', 'is_default'

    ];

    public function user(Theme $theme) //return user name with created_id
    {

        $user_id = $theme->created_by;

        $user = User::find($user_id);

        return $user->name;

    }

    public function updateUser(Theme $theme) //return user name with last_updated_by
    {

        $user_id = $theme->last_updated_by;

        $user = User::find($user_id);

        if ($user)
            return $user->name;

        return 'Non';

    }

}
