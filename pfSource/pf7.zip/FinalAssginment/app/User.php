<?php

namespace App;

use Laravel\Scout\Searchable; // searching

use Illuminate\Database\Eloquent\SoftDeletes; // soft delete

use Illuminate\Foundation\Auth\User as Authenticatable;


class User extends Authenticatable
{
    use SoftDeletes; // soft delete

    use Searchable; // searching (scout)

    protected $dates = ['deleted_at']; // soft delete

    protected $fillable = [

        'name', 'email', 'password',

    ];

    protected $hidden = [

        'password', 'remember_token',

    ];

    // User Role
    public function roles()
    {

        return $this->belongsToMany(Role::class);

    }

    public function authorizeRoles($roles)
    {

        if (is_array($roles))
        {

            return $this->hasUserRole() ||
                abort(401, 'This action is unauthorized.');

        }

        return $this->hasRole($roles) ||
            abort(401, 'This action is unauthorized.');

    }

    public function hasUserRole()
    {
        return null !== $this->roles()->where('name', 'User')->first();
    }

    public function hasRole($role)
    {
        return null !== $this->roles()->where('name', $role)->first();
    }

    // User Searching
    public function searchableAs()
    {

        return 'users_index';

    }

    public function deletedBy(User $user) //return user name with created_id
    {

        $user_id = $user->deleted_by;

        $deletedBy = User::find($user_id);

        return $deletedBy->name;

    }

}
