<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\DB;
use App\Theme;

class AppServiceProvider extends ServiceProvider
{

    public function boot()
    {
        $themes = Theme::all();

        $default_theme = DB::table('themes')->where('is_default', '1')->value('cdn_url');

        view()->share(compact('themes', 'default_theme'));
    }

    public function register()
    {
        //
    }

}
