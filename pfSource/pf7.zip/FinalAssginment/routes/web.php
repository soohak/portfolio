<?php

//Checking user role for each route
use App\Http\Middleware\CheckIsUserAdmin;
use App\Http\Middleware\CheckIsThemeManager;
use App\Http\Middleware\CheckIsPostModerator;


/** Auth control part  **********************************************/

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');



/** Post control part  **********************************************/

// Show all posts in Main Home
Route::get('/', 'PostController@index');

// Show all post in post management
Route::get('/posts', 'PostController@exists')->middleware(CheckIsPostModerator::class);

// Create new post
Route::get('/posts/create', 'PostController@create'); //show the post form
Route::post('/posts', 'PostController@store'); // create new post

//// Editing
Route::get('/posts/{post}/edit', 'PostController@edit')->middleware(CheckIsPostModerator::class);
Route::post('/posts/{post}/update', 'PostController@update')->middleware(CheckIsPostModerator::class);

// Show one post by id
Route::get('/posts/{post}', 'PostController@show');

// Soft deleting
Route::get('/posts/delete/{post}', 'PostController@destroy')->middleware(CheckIsPostModerator::class);



/** Theme control part  **********************************************/

// Show all post in post management
Route::get('/themes', 'ThemeController@index')->middleware(CheckIsThemeManager::class);

// Create new post
Route::get('/themes/create', 'ThemeController@create')->middleware(CheckIsThemeManager::class);
Route::post('/themes', 'ThemeController@store')->middleware(CheckIsThemeManager::class);

// Show Detail theme
Route::get('/themes/{theme}', 'ThemeController@show')->middleware(CheckIsThemeManager::class);

// Editing
Route::get('/themes/{theme}/edit', 'ThemeController@edit')->middleware(CheckIsThemeManager::class);
Route::post('/themes/{theme}/update', 'ThemeController@update')->middleware(CheckIsThemeManager::class);

// Delete (hard deleting)
Route::get('/themes/delete/{theme}', 'ThemeController@destroy')->middleware(CheckIsThemeManager::class);



/** User control part  **********************************************/

// Show all
Route::get('/users', 'UserController@index')->middleware(CheckIsUserAdmin::class);

// Searching
Route::post('/users', 'UserController@search')->middleware(CheckIsUserAdmin::class);

// Editing
Route::get('/users/{user}/edit', 'UserController@edit')->middleware(CheckIsUserAdmin::class);
Route::post('/users/{user}/update', 'UserController@update')->middleware(CheckIsUserAdmin::class);

// Show the soft deleted users
Route::get('/users/trash', 'UserController@trash')->middleware(CheckIsUserAdmin::class);

// Soft deleting
Route::get('/users/delete/{user}', 'UserController@destroy')->middleware(CheckIsUserAdmin::class);

// Restore
Route::get('/users/trash/{user}/restore', 'UserController@restore')->middleware(CheckIsUserAdmin::class);


