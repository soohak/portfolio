@extends('layouts.management')

@section('content')

    <div class="col-sm-8">

        <h1>Update Post</h1>

        <form method="POST" action="/posts/{{$post->id}}/update">

            {{csrf_field()}}

            <div class="form-group">

                <label for="title">Title:</label>

                <input type="text" class="form-control" id="title" name="title" value="{{$post->title}}" >

            </div>

            <div class="form-group">

                <label for="body">Body:</label>

                <textarea id="body" name="body" class="form-control" >{{$post->body}}</textarea>

            </div>

            <div class="form-group">

                <label for="link">Link:</label>

                <input type="text" class="form-control" id="link" name="link" value="{{$post->link}}" >

            </div>

            <div class="form-group">

                <button type="submit" class="btn btn-primary">Modify</button>

            </div>

        </form>
        @include('layouts.errors')

    </div>

@endsection