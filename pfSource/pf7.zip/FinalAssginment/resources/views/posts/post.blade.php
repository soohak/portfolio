<div class="blog-post">

    <h2 class="blog-post-title">

        <a href="/posts/{{$post->id}}">{{$post->title}}</a>

    </h2>

    <p class="blog-post-meta">

        {{$post->created_at->toFormattedDateString()}} by {{$post->user($post)}}

    </p>

    <p class="blog-post-body">

        {{$post->body}}

    </p>

    <img class="img-thumbnail" src="{{$post->link}}" alt="Image for this post" />

</div>
