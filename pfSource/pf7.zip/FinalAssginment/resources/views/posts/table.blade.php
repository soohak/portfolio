@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <h1>Post Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>Post ID</th>
                <th>Title</th>
                <th>Body</th>
                <th>Create by</th>
                <th>Last Update by</th>
                <th>Link</th>
                <th>Modify</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            @foreach($posts as $post)

                <tr>
                    <td>{{$post->id}}</td>

                    <td>{{$post->title}}</td>

                    <td>{{$post->body}}</td>

                    <td>{{$post->user($post)}}</td>

                    <td>{{$post->updateUser($post)}}</td>

                    <td>{{$post->link}}</td>

                    <td><a class="btn btn-outline-primary" href="/posts/{{$post->id}}/edit">Modify</a></td>

                    <td><a class="btn btn-outline-secondary" href="/posts/delete/{{$post->id}}">Delete</a></td>

                </tr>

            @endforeach

            </tbody>
            <tfoot></tfoot>
        </table>

    </div><!-- /.blog-main -->

@endsection
