@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <div class="blog-post">

            <h2 class="blog-post-title">{{$post->title}}</h2><br/>

            <ul>

                <li><p><b>Created at: </b>{{$post->created_at->toFormattedDateString()}}</p></li>

                <li><p><b>Created by: </b>{{$post->user($post)}}</p></li>

                <li><p><b>Last Updated at: </b>{{$post->updated_at->toFormattedDateString()}}</p></li>

                <li><p><b>Last Updated by: </b>{{$post->updateUser($post)}}</p></li>

                <li><p><b>Body: </b>{{$post->body}}</p></li>

            </ul>

            <img class="img-thumbnail" src="{{$post->link}}" alt="Image for this post" />

            <p><b>Link :</b> {{$post->link}}</p>

            <a class="btn btn-outline-primary" href="{{url('/')}}">Go to Main</a>

        </div>

    </div>

@endsection