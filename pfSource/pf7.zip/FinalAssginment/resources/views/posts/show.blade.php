@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        @include('posts.post')

    </div><!-- /.blog-main -->

@endsection