@component('mail::message')
# Introduction

Thanks so much for registering!


@component('mail::button', ['url' => 'http://localhost:8000'])
Let's go to Blogging!
@endcomponent

@component('mail::panel', ['url' => ''])
    This mail come from the final projet Blog!
@endcomponent


Thanks,<br>
{{ $user->name }}
@endcomponent
