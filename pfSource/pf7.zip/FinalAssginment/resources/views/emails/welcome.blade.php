<!DOCTYPE html>
<html>

<head>

</head>

<body>

<h1>Welcome to Final Project Blog, {{$user->name}}</h1>

</body>

</html>