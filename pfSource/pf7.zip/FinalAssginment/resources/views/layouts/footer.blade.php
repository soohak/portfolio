<footer class="blog-footer">
    <p>Soohak KIM &#8226; Halifax, NS CANADA &#8226; E-mail <a href="mailto: soohagi@gmail.com">soohagi@gmail.com</a></p>
    <p>
        <a href="#">Back to top</a>
    </p>
</footer>