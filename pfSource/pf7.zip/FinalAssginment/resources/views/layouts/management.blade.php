
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="">

    <title>Final Project - PHP</title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href={{$default_theme}}>

    <!-- Custom styles for this template -->
    <link href="/css/blog.css" rel="stylesheet">


</head>

<body>

@include('layouts.nav')

<div class="blog-header">

    <div class="container">

        <h1 class="blog-title">FINAL ASSIGNMENT</h1>

        <p class="lead blog-description">SIMPLE, CUSTOM SOCIAL MEDIA FEED IN PHP & MYSQL.</p>

    </div>

</div>

<div class="container">

    <div class="row">

        @yield('content')

    </div>

</div>

@include('layouts.footer')

</body>

</html>
