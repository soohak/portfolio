<div class="col-sm-3 offset-sm-1 blog-sidebar">

    <div class="sidebar-module sidebar-module-inset">

        <h5 style="font-weight: bold">Current Posts List</h5>

            @foreach($posts as $post)

            <a href="/posts/{{$post->id}}">{{$post->title}} <p>({{$post->created_at->toDateString()}})</p></a>

            @endforeach

    </div>




</div><!-- /.blog-sidebar -->