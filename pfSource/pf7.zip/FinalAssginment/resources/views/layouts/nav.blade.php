<div class="blog-masthead">

    <div class="container">

        <nav class="nav blog-nav">

            <a class="nav-link active" href="../">Home</a>

            @if (Auth::check())

            <a class="nav-link" href="/posts/create">New Post</a>

                @if (Auth::check() && Auth::user()->hasRole('User Administrator'))
                <a class="nav-link" href="/users">User Management</a>
                @endif


                @if (Auth::check() && Auth::user()->hasRole('Theme Manager'))
                <a class="nav-link" href="/themes">Theme Management</a>
                @endif


                @if (Auth::check() && Auth::user()->hasRole('Post Moderator'))
                <a class="nav-link" href="/posts">Post Management</a>
                @endif

            <a class="nav-link ml-auto" href="#">{{Auth::user()->name}}</a>

            <a class="nav-link" href="/register">LogOut</a>

            @else
                <a class="nav-link ml-auto" href="/register">Registration/Login</a>
            @endif

        </nav>

    </div>

</div>
