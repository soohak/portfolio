@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <h1>User Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            @foreach($users as $user)

                <tr>
                    <td>{{$user->id}}</td>

                    <td>{{$user->name}}</td>

                    <td>{{$user->email}}</td>

                    @if($user->id === 1)
                        <td>Root Admin</td>
                    @else
                        <td><a class="btn btn-outline-primary" href="/users/{{$user->id}}/edit">Modify</a></td>
                    @endif

                    @if($user->id === 1)
                        <td>Root Admin</td>
                    @else
                        <td><a class="btn btn-outline-secondary" href="/users/delete/{{$user->id}}">Delete</a></td>
                    @endif
                </tr>

            @endforeach

            </tbody>
            <tfoot></tfoot>
        </table>

        <nav class="blog-pagination">

            <form class="card p-2" method="POST" action='/users' >

                {{csrf_field()}}

                <div class="input-group">

                    <input type="text" class="form-control" name="search" id="search"
                           placeholder="User name or email" />

                    <input type="submit" class="btn btn-secondary" value="Searching"/>

                </div>

            </form><br/>

            <a class="btn btn-outline-primary" href="/users/trash">Go to Deleted User</a>


        </nav>

    </div><!-- /.blog-main -->

@endsection
