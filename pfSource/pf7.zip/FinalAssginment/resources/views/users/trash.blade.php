@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <table class="table">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Deleted at</th>
                <th>Deleted by</th>
                <th>Restore</th>
            </tr>
            </thead>
            <tbody>
            @foreach($users as $user)

                <tr>
                    <td>{{$user->id}}</td>

                    <td>{{$user->name}}</td>

                    <td>{{$user->email}}</td>

                    <td>{{$user->deleted_at}}</td>

                    <td>{{$user->deletedBy($user)}}</td>

                    <td><a class="btn btn-outline-primary" href="/users/trash/{{$user->id}}/restore">Restore</a></td>

                </tr>

            @endforeach

            </tbody>
            <tfoot></tfoot>
        </table>

    </div><!-- /.blog-main -->

@endsection
