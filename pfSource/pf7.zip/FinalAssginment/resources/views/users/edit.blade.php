@extends('layouts.management')

@section('content')

    <div class="col-sm-8">

        <form method="POST" action="/users/{{$user->id}}/update">

            {{csrf_field()}}

            <div class="form-group">

                <label for="name">Name:</label>

                <input type="text" class="form-control" id="name" name="name" value="{{$user->name}}" >

            </div>

            <div class="form-group">

                <label for="email">Email:</label>

                <input type="email" class="form-control" id="email" name="email" value="{{$user->email}}" >

            </div>

            <div class="form-group">

                <div class="checkbox mb-3">

                    <label>
                        @if ($user->hasRole('User Administrator'))
                            <input id="userMng" name="userMng" type="checkbox" value="User Administrator" checked="true"> User Administrator
                        @else
                            <input id="userMng" name="userMng" type="checkbox" value="User Administrator"> User Administrator
                        @endif
                    </label>

                    <label>
                        @if ($user->hasRole('Theme Manager'))
                            <input id="themeMng" name="themeMng" type="checkbox" value="Theme Manager" checked="true"> Theme Manager
                        @else
                            <input id="themeMng" name="themeMng" type="checkbox" value="Theme Manager"> Theme Manager
                        @endif
                    </label>

                    <label>
                        @if ($user->hasRole('Post Moderator'))
                            <input id="postMng" name="postMng" type="checkbox" value="Post Moderator" checked="true"> Post Moderator
                        @else
                        <input id="postMng" name="postMng" type="checkbox" value="Post Moderator"> Post Moderator
                        @endif
                    </label>
                </div>

            </div>

            <div class="form-group">

                <button type="submit" class="btn btn-primary">Modify</button>

            </div>

        </form>
        @include('layouts.errors')
    </div>
@endsection
