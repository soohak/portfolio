@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <div class="blog-post">

            <h2 class="blog-post-title">

                {{$theme->name}}

            </h2><br/>

            Created at: <p>{{$theme->created_at->toFormattedDateString()}}</p>

            Created by: <p>{{$theme->user($theme)}}</p>

            Last Updated at: <p>{{$theme->updated_at->toFormattedDateString()}}</p>

            Last Updated by: <p>{{$theme->updateUser($theme)}}</p>

            Description: <p>{{$theme->description}}</p>

            CDN URL: <p>{{$theme->cdn_url}} </p>

        </div>
        <a class="btn btn-outline-primary" href="/themes">Go to Theme Main</a>
    </div>


@endsection