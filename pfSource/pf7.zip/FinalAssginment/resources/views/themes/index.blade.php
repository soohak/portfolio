@extends('layouts.management')

@section('content')

    <div class="col-sm-8 blog-main">

        <h1>Theme Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>Theme ID</th>
                <th>Name</th>
                <th>CDN URL</th>
                <th>Default</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            @foreach($themes as $theme)

                <tr>

                    <td>{{$theme->id}}</td>

                    <td>{{$theme->name}}</td>

                    <td>{{$theme->cdn_url}}</td>

                    @if ($theme->is_default ===1)
                        <td>Yes</td>
                    @else
                        <td>No</td>
                    @endif

                    <td><a class="btn btn-outline-primary" href="/themes/{{$theme->id}}">Detail</a></td>

                    <td><a class="btn btn-outline-primary" href="/themes/{{$theme->id}}/edit">Edit</a></td>
                    @if ($theme->id ===1)
                        <td>Basic Theme</td>
                    @else
                    <td><a class="btn btn-outline-secondary" href="/themes/delete/{{$theme->id}}">Delete</a></td>
                    @endif

                </tr>

            @endforeach

            </tbody>
            <tfoot></tfoot>
        </table>

        <a class="btn btn-outline-primary" href="/themes/create">Insert</a>

    </div><!-- /.blog-main -->

@endsection
