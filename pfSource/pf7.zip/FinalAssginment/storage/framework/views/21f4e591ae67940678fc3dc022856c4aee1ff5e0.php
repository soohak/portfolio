<?php $__env->startComponent('mail::message'); ?>
# Introduction

Thanks so much for registering!


<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:8000']); ?>
Let's go to Blogging!
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::panel', ['url' => '']); ?>
    This mail come from the final projet Blog!
<?php echo $__env->renderComponent(); ?>


Thanks,<br>
<?php echo e($user->name); ?>

<?php echo $__env->renderComponent(); ?>
