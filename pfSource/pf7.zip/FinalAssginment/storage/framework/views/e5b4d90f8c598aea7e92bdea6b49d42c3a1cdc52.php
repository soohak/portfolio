<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <table class="table">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($user->id); ?></td>

                    <td><?php echo e($user->name); ?></td>

                    <td><?php echo e($user->email); ?></td>

                    <td><a class="btn btn-outline-primary" href="#">Modify</a></td>

                    <td><a class="btn btn-outline-secondary" href="#">Delete</a></td>
                </tr>
            </tbody>
            <tfoot></tfoot>
        </table>

    </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>