<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <h1>User Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->id); ?></td>

                    <td><?php echo e($user->name); ?></td>

                    <td><?php echo e($user->email); ?></td>

                    <?php if($user->id === 1): ?>
                        <td>Root Admin</td>
                    <?php else: ?>
                        <td><a class="btn btn-outline-primary" href="/users/<?php echo e($user->id); ?>/edit">Modify</a></td>
                    <?php endif; ?>

                    <?php if($user->id === 1): ?>
                        <td>Root Admin</td>
                    <?php else: ?>
                        <td><a class="btn btn-outline-secondary" href="/users/delete/<?php echo e($user->id); ?>">Delete</a></td>
                    <?php endif; ?>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot></tfoot>
        </table>

        <nav class="blog-pagination">

            <form class="card p-2" method="POST" action='/users' >

                <?php echo e(csrf_field()); ?>


                <div class="input-group">

                    <input type="text" class="form-control" name="search" id="search"
                           placeholder="User name or email" />

                    <input type="submit" class="btn btn-secondary" value="Searching"/>

                </div>

            </form><br/>

            <a class="btn btn-outline-primary" href="/users/trash">Go to Deleted User</a>


        </nav>

    </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>