<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <h1>Create new theme</h1>

        <form method="POST" action="/themes">

            <?php echo e(csrf_field()); ?>


            <div class="form-group">

                <label for="name">Name:</label>

                <input type="text" class="form-control" id="name" name="name" >

            </div>

            <div class="form-group">

                <label for="description">Description:</label>

                <textarea id="description" name="description" class="form-control"></textarea>

            </div>

            <div class="form-group">

                <label for="cdn_url">CDN URL:</label>

                <input type="text" class="form-control" id="cdn_url" name="cdn_url" >

            </div>

            <div class="checkbox mb-3">

                <label>
                    <input id="isDefault" name="isDefault" type="checkbox"> Do you want to set a default with new theme
                </label>

            </div>

            <div class="form-group">

                <button type="submit" class="btn btn-primary">Save</button>

            </div>

        </form>

        <?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>