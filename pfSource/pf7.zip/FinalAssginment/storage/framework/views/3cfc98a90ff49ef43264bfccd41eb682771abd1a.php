<div class="col-sm-3 offset-sm-1 blog-sidebar">

    <div class="sidebar-module sidebar-module-inset">

        <h6>Your Current Theme</h6>

            <select id="chooseTheme" name="chooseTheme" >

                <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                    <option value="<?php echo e($theme->id); ?>" ><?php echo e($theme->name); ?></option>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

    </div>




</div><!-- /.blog-sidebar -->