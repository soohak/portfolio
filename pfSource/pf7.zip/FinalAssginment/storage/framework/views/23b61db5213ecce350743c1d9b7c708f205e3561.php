<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <table class="table">
            <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Restore</th>
                <th>Permanent Deleting</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->id); ?></td>

                    <td><?php echo e($user->name); ?></td>

                    <td><?php echo e($user->email); ?></td>

                    <td><a class="btn btn-outline-primary" href="/users/<?php echo e($user->id); ?>/restore">Restore</a></td>

                    <td><a class="btn btn-outline-secondary" href="/users/<?php echo e($user->id); ?>/Permanent">Delete</a></td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot></tfoot>
        </table>

    </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>