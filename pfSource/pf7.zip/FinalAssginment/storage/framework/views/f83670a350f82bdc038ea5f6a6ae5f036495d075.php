<!DOCTYPE html>
<html>
<head>

</head>

<body>

<h1>Welcome to Final Project Blog, <?php echo e($user->name); ?></h1>


</body>

</html>