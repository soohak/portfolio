<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <h1>Theme Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>Theme ID</th>
                <th>Name</th>
                <th>CDN URL</th>
                <th>Default</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>

                    <td><?php echo e($theme->id); ?></td>

                    <td><?php echo e($theme->name); ?></td>

                    <td><?php echo e($theme->cdn_url); ?></td>

                    <?php if($theme->is_default ===1): ?>
                        <td>Yes</td>
                    <?php else: ?>
                        <td>No</td>
                    <?php endif; ?>

                    <td><a class="btn btn-outline-primary" href="/themes/<?php echo e($theme->id); ?>">Detail</a></td>

                    <td><a class="btn btn-outline-primary" href="/themes/<?php echo e($theme->id); ?>/edit">Edit</a></td>
                    <?php if($theme->id ===1): ?>
                        <td>Basic Theme</td>
                    <?php else: ?>
                    <td><a class="btn btn-outline-secondary" href="/themes/delete/<?php echo e($theme->id); ?>">Delete</a></td>
                    <?php endif; ?>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot></tfoot>
        </table>

        <a class="btn btn-outline-primary" href="/themes/create">Insert</a>

    </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>