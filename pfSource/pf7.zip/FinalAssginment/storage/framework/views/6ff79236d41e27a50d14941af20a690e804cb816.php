<div class="blog-post">

    <h2 class="blog-post-title">

        <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>

    </h2>

    <p class="blog-post-meta">

        <?php echo e($post->created_at->toFormattedDateString()); ?> by <?php echo e($post->user($post)); ?>


    </p>

    <p class="blog-post-body">

        <?php echo e($post->body); ?>


    </p>

    <img class="img-thumbnail" src="<?php echo e($post->link); ?>" alt="Image for this post" />

</div>
