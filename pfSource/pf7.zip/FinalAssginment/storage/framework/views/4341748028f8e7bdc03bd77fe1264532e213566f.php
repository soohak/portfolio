<?php $__env->startSection('content'); ?>

    <div class="col-sm-8">

        <form method="POST" action="/users/<?php echo e($user->id); ?>/update">

            <?php echo e(csrf_field()); ?>


            <div class="form-group">

                <label for="name">Name:</label>

                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>

            </div>

            <div class="form-group">

                <label for="email">Email:</label>

                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>

            </div>

            <div class="form-group">

                <div class="checkbox mb-3">

                    <label>
                        <?php if($user->hasRole('User Administrator')): ?>
                            <input id="userMng" name="userMng" type="checkbox" value="User Administrator" checked="true"> User Administrator
                        <?php else: ?>
                            <input id="userMng" name="userMng" type="checkbox" value="User Administrator"> User Administrator
                        <?php endif; ?>
                    </label>

                    <label>
                        <?php if($user->hasRole('Theme Manager')): ?>
                            <input id="themeMng" name="themeMng" type="checkbox" value="Theme Manager" checked="true"> Theme Manager
                        <?php else: ?>
                            <input id="themeMng" name="themeMng" type="checkbox" value="Theme Manager"> Theme Manager
                        <?php endif; ?>
                    </label>

                    <label>
                        <?php if($user->hasRole('Post Moderator')): ?>
                            <input id="postMng" name="postMng" type="checkbox" value="Post Moderator" checked="true"> Post Moderator
                        <?php else: ?>
                        <input id="postMng" name="postMng" type="checkbox" value="Post Moderator"> Post Moderator
                        <?php endif; ?>
                    </label>
                </div>

            </div>

            <div class="form-group">

                <button type="submit" class="btn btn-primary">Modify</button>

            </div>

        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>