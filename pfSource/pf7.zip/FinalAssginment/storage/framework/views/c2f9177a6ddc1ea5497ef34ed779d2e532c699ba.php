<div class="col-sm-3 offset-sm-1 blog-sidebar">

    <div class="sidebar-module sidebar-module-inset">

        <h5 style="font-weight: bold">Current Posts List</h5>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?> <p>(<?php echo e($post->created_at->toDateString()); ?>)</p></a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>




</div><!-- /.blog-sidebar -->