<div class="blog-post">

    <h2 class="blog-post-title">

        <?php echo e($theme->title); ?>


    </h2>

    <p class="blog-post-meta">

        <?php echo e($theme->created_at); ?> by <?php echo e($theme->user($theme)); ?>


    </p>

    <p class="blog-post-body">

        <?php echo e($theme->description); ?>


    </p>

    <img class="img-thumbnail" src="<?php echo e($theme->cdn_url); ?>" alt="Image for this post" />

</div>