<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <h1>Post Management</h1>

        <table class="table">
            <thead>
            <tr>
                <th>Post ID</th>
                <th>Title</th>
                <th>Body</th>
                <th>Create by</th>
                <th>Last Update by</th>
                <th>Link</th>
                <th>Modify</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($post->id); ?></td>

                    <td><?php echo e($post->title); ?></td>

                    <td><?php echo e($post->body); ?></td>

                    <td><?php echo e($post->user($post)); ?></td>

                    <td><?php echo e($post->updateUser($post)); ?></td>

                    <td><?php echo e($post->link); ?></td>

                    <td><a class="btn btn-outline-primary" href="/posts/<?php echo e($post->id); ?>/edit">Modify</a></td>

                    <td><a class="btn btn-outline-secondary" href="/posts/delete/<?php echo e($post->id); ?>">Delete</a></td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot></tfoot>
        </table>

    </div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>