<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">

        <div class="blog-post">

            <h2 class="blog-post-title">

                <?php echo e($theme->name); ?>


            </h2><br/>

            Created at: <p><?php echo e($theme->created_at->toFormattedDateString()); ?></p>

            Created by: <p><?php echo e($theme->user($theme)); ?></p>

            Last Updated at: <p><?php echo e($theme->updated_at->toFormattedDateString()); ?></p>

            Last Updated by: <p><?php echo e($theme->updateUser($theme)); ?></p>

            Description: <p><?php echo e($theme->description); ?></p>

            CDN URL: <p><?php echo e($theme->cdn_url); ?> </p>

        </div>
        <a class="btn btn-outline-primary" href="/themes">Go to Theme Main</a>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.management', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>