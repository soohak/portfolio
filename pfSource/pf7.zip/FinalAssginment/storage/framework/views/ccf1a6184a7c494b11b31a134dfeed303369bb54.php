<div class="blog-masthead">

    <div class="container">

        <nav class="nav blog-nav">

            <a class="nav-link active" href="../">Home</a>

            <?php if(Auth::check()): ?>

            <a class="nav-link" href="/posts/create">New Post</a>

                <?php if(Auth::check() && Auth::user()->hasRole('User Administrator')): ?>
                <a class="nav-link" href="/users">User Management</a>
                <?php endif; ?>


                <?php if(Auth::check() && Auth::user()->hasRole('Theme Manager')): ?>
                <a class="nav-link" href="/themes">Theme Management</a>
                <?php endif; ?>


                <?php if(Auth::check() && Auth::user()->hasRole('Post Moderator')): ?>
                <a class="nav-link" href="/posts">Post Management</a>
                <?php endif; ?>

            <a class="nav-link ml-auto" href="#"><?php echo e(Auth::user()->name); ?></a>

            <a class="nav-link" href="/register">LogOut</a>

            <?php else: ?>
                <a class="nav-link ml-auto" href="/register">Registration/Login</a>
            <?php endif; ?>

        </nav>

    </div>

</div>
