<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>INET Final Project - PHP laravel</title>

</head>

<body>

</body>

</html>