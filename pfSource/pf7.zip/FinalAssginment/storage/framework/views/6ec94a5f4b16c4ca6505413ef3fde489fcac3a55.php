<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">

    <meta name="author" content="">

    <title>Final Project - PHP</title>

    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
            integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
            crossorigin="anonymous"></script>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href=<?php echo e($default_theme); ?>>

    <!-- Custom styles for this template -->
    <link href="/css/blog.css" rel="stylesheet">

</head>

<body>

<div id="posts">

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if($flash = session('message')): ?>

    <div id="flash-message" class="alert alert-success" role="alert">

        <?php echo e($flash); ?>


    </div>

<?php endif; ?>

<div class="blog-header">

    <div class="container">

        <h1 class="blog-title">FINAL ASSIGNMENT</h1>

        <p class="lead blog-description">SIMPLE, CUSTOM SOCIAL MEDIA FEED IN PHP & MYSQL.</p>

    </div>

</div>

<div class="container">

    <div class="row">

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <script>

            function doPoll(){

            console.log('ajax call');

            $.ajax({

                url:'http://localhost:8000/',
                success: function(result){

                document.getElementById('posts').innerHTML = '';

                $("#posts").eq(0).append(($.parseHTML(result)));
                }
            });

                setTimeout(doPoll, 5000);
            }

            setTimeout(doPoll, 5000);

        </script>

    </div>

    <a class="btn btn-outline-primary" href="#">Go to Top</a><br/>


</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

</body>

</html>