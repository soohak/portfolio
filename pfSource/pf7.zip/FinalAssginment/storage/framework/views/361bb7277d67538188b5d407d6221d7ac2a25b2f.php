<div class="blog-post">

    <h2 class="blog-post-title">

        <a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->name); ?></a>

    </h2>

    <p class="blog-post-meta">

        <?php echo e($user->created_at->toFormattedDateString()); ?> by <a href="#">Soohak</a>

    </p>

</div>