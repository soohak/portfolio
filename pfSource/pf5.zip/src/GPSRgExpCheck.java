import java.util.regex.Pattern;

public class GPSRgExpCheck {

	protected String regExp;
	
	//constructor
	public GPSRgExpCheck() {
		this.regExp = "^\\d{2}\\.\\d{7}-\\d{2}\\.\\d{7}$";; //regular expression for GPS coordinate("00.0000000-00.0000000")
	}
	
	
	// Method to check the GPS coordinate
	public boolean regExpGPSInfo(String input)
	{
		String GPSCoordinate = input;
		boolean result = Pattern.matches(this.getRegExp(), GPSCoordinate);
		
		if(result)
			return true;
		else 
			return false;
	}

	//get & set methods
	public String getRegExp() {
		return regExp;
	}


	public void setRegExp(String regExp) {
		this.regExp = regExp;
	}
}
