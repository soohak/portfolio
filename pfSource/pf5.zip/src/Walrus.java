
public class Walrus extends Animal {
	
	protected String dentalHealth;
	
	@Override
	public void specialInfo(double bP, int NoS, String dentH) {// specialInfo() for Walrus
		String dentHealth;
		this.dentalHealth = dentH;
		dentHealth = "Status is "+this.dentalHealth;
		this.setSpecialInfo(dentHealth);
	}

	
	@Override
	public void reportForm() {
		String addRptForm;
		addRptForm = "Animal Name: "+this.getAniName()
				+"\nSpecies: "+this.getSpecies()
				+"\nSex: "+this.getSex()
				+"\nWeight: "+this.getWeight()+"Kg"
				+"\nGPS Coordinate: "+this.getGPSInfo()
				+"\nDental Health: "+this.getSpecialInfo()+"\n\n";
		this.setRptForm(addRptForm);
	}

	
	//constructor
	public Walrus(){
		this.AniName = "Walrus";
		this.Species = "Odobenus rosmarus";
		this.Sex = true;
		this.Weight = "Input Weight(Kg)";
		this.GPSInfo = "00.0000000-00.0000000";
		this.SpecialInfo = "Input Dental Health(Good/Average/Poor)";
		this.RptForm = "Report";
	} 

}
