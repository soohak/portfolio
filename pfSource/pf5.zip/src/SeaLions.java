
public class SeaLions extends Animal {
	
	protected int numberOfSpots;

	@Override
	public void specialInfo(double bP, int NoS, String dentH) {// specialInfo() for SeaLions
		String nSpots;
		this.numberOfSpots = NoS;
		nSpots = this.numberOfSpots+" spots";
		this.setSpecialInfo(nSpots);;
	}
	
	@Override
	public void reportForm() {
		String addRptForm;
		addRptForm = "Animal Name: "+this.getAniName()
				+"\nSpecies: "+this.getSpecies()
				+"\nSex: "+this.getSex()
				+"\nWeight: "+this.getWeight()+"Kg"
				+"\nGPS Coordinate: "+this.getGPSInfo()
				+"\nNumber of spots: "+this.getSpecialInfo()+"\n\n";
		this.setRptForm(addRptForm);
	}
	
	//constructor
	public SeaLions(){
		this.AniName = "SeaLions";
		this.Species = "Otariidae";
		this.Sex = true;
		this.Weight = "Input Weight(Kg)";
		this.GPSInfo = "00.0000000-00.0000000";
		this.SpecialInfo = "Input the number of sopts";
		this.RptForm = "Report";
	} 
}
