import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class AppFrame extends JFrame {

	private JPanel contentPane;
	private JTextField txtSpecies;
	private JTextField txtWeight;
	private JTextField txtGps;
	private JTextField txtSpecialInfo;
	
	/* Launch the application */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppFrame frame = new AppFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	//ArrayList
	ArrayList<String> reportList = new ArrayList<>();
	// File path for report
	Path report = Paths.get("Report.txt");	
	//Object instance for Penquins, Sea lions, and Walrus, set default values
	Animal Penguins = (Animal) new Penguins();
	Animal SeaLions = (Animal) new SeaLions();
	Animal Walrus = (Animal) new Walrus();
	//Object instance for GPS
	GPSRgExpCheck GPS = new GPSRgExpCheck();
	//Object instance for ValidatonClass
	ValidatonClass validate = new ValidatonClass();
	//Object instance for File I/O
	Controller FileIO = new Controller(report); 
	
	/* Create the frame */
	public AppFrame() {
		
		setTitle("Antarctic Wildlife Tracking System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 669, 371);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(153, 204, 255));
		contentPane.add(panel_1, "name_16570159639999");
		panel_1.setLayout(null);
		
		final JComboBox cboName = new JComboBox();
		cboName.setBounds(29, 33, 128, 29);
		cboName.setModel(new DefaultComboBoxModel(new String[] {"Select Animal", "Penguins", "Sea lions", "Walrus"}));
		panel_1.add(cboName);
		
		JLabel lblSpecies = new JLabel("Species:");
		lblSpecies.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSpecies.setForeground(new Color(0, 0, 204));
		lblSpecies.setBounds(29, 73, 105, 14);
		panel_1.add(lblSpecies);
		
		JLabel lblAnimalName = new JLabel("Animal Name"); 
		lblAnimalName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAnimalName.setForeground(new Color(0, 0, 204));
		lblAnimalName.setBounds(29, 11, 122, 20);
		panel_1.add(lblAnimalName);
		
		JLabel lblWeight = new JLabel("Weight:");
		lblWeight.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblWeight.setForeground(new Color(0, 0, 204));
		lblWeight.setBounds(154, 73, 105, 14);
		panel_1.add(lblWeight);
		
		JLabel lblSex = new JLabel("Sex:");
		lblSex.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSex.setForeground(new Color(0, 0, 204));
		lblSex.setBounds(29, 132, 105, 14);
		panel_1.add(lblSex);
		
		JLabel lblTrackRpt = new JLabel("Tracking Report:");
		lblTrackRpt.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTrackRpt.setForeground(new Color(0, 0, 204));
		lblTrackRpt.setBounds(315, 48, 105, 14);
		panel_1.add(lblTrackRpt);
		
		JLabel lblGpsInfo = new JLabel("GPS Information");
		lblGpsInfo.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblGpsInfo.setForeground(new Color(0, 0, 204));
		lblGpsInfo.setBounds(29, 262, 105, 14);
		panel_1.add(lblGpsInfo);
		
		JLabel lblSpecialInfo = new JLabel("Special Information");
		lblSpecialInfo.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSpecialInfo.setForeground(new Color(0, 0, 204));
		lblSpecialInfo.setBounds(29, 197, 128, 14);
		panel_1.add(lblSpecialInfo);
		
		JButton btnMakeRpt = new JButton("Make Report");
		btnMakeRpt.setEnabled(false);
		btnMakeRpt.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnMakeRpt.setBackground(new Color(204, 204, 255));
		btnMakeRpt.setForeground(new Color(0, 0, 255));
		btnMakeRpt.setBounds(315, 282, 128, 29);
		panel_1.add(btnMakeRpt);
		
		JButton btnAddToList = new JButton("Add to List");
		btnAddToList.setEnabled(false);
		btnAddToList.setBackground(new Color(51, 153, 153));
		btnAddToList.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAddToList.setForeground(new Color(0, 102, 0));
		btnAddToList.setBounds(453, 282, 128, 29);
		panel_1.add(btnAddToList);
		
		JButton btnSaveFile = new JButton("Save to File");
		btnSaveFile.setForeground(new Color(0, 102, 0));
		btnSaveFile.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSaveFile.setEnabled(false);
		btnSaveFile.setBackground(new Color(51, 153, 153));
		btnSaveFile.setBounds(413, 10, 105, 23);
		panel_1.add(btnSaveFile);
		
		JButton btnReadFile = new JButton("Read File");
		btnReadFile.setForeground(new Color(0, 102, 0));
		btnReadFile.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnReadFile.setBackground(new Color(51, 153, 153));
		btnReadFile.setBounds(528, 10, 105, 23);
		panel_1.add(btnReadFile);
		
		txtWeight = new JTextField();
		txtWeight.setText("Weight");
		txtWeight.setHorizontalAlignment(SwingConstants.CENTER);
		txtWeight.setColumns(10);
		txtWeight.setBounds(154, 92, 105, 29);
		panel_1.add(txtWeight);
		
		txtSpecies = new JTextField();
		txtSpecies.setText("Scientific Name");
		txtSpecies.setHorizontalAlignment(SwingConstants.CENTER);
		txtSpecies.setColumns(10);
		txtSpecies.setBounds(29, 92, 105, 29);
		panel_1.add(txtSpecies);
		
		txtGps = new JTextField();
		txtGps.setText("Input GPS coordinate");
		txtGps.setHorizontalAlignment(SwingConstants.CENTER);
		txtGps.setColumns(10);
		txtGps.setBounds(29, 282, 230, 29);
		panel_1.add(txtGps);
		
		txtSpecialInfo = new JTextField();
		txtSpecialInfo.setText("Write special information");
		txtSpecialInfo.setHorizontalAlignment(SwingConstants.CENTER);
		txtSpecialInfo.setColumns(10);
		txtSpecialInfo.setBounds(29, 219, 230, 29);
		panel_1.add(txtSpecialInfo);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(315, 63, 318, 213);
		panel_1.add(scrollPane);
		
		final JTextArea textAreaReport = new JTextArea();
		scrollPane.setViewportView(textAreaReport);
		textAreaReport.setEditable(false);
		textAreaReport.setForeground(new Color(255, 255, 255));
		textAreaReport.setBackground(new Color(51, 153, 204));
		
		JRadioButton rdbtnSexM = new JRadioButton("Male");
		rdbtnSexM.setFont(new Font("Tahoma", Font.BOLD, 11));
		rdbtnSexM.setForeground(new Color(255, 102, 0));
		rdbtnSexM.setBackground(new Color(153, 204, 255));
		rdbtnSexM.setSelected(true);
		rdbtnSexM.setBounds(29, 153, 55, 23);
		panel_1.add(rdbtnSexM);
		
		JRadioButton rdbtnSexF = new JRadioButton("Female");
		rdbtnSexF.setFont(new Font("Tahoma", Font.BOLD, 11));
		rdbtnSexF.setForeground(new Color(255, 102, 0));
		rdbtnSexF.setBackground(new Color(153, 204, 255));
		rdbtnSexF.setBounds(86, 153, 79, 23);
		panel_1.add(rdbtnSexF);
		
		/* Action Listeners */	
		//Action Listeners for selected name
		cboName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(cboName.getSelectedIndex() == 0) {
					txtSpecies.setText("Scientific Name");
					txtWeight.setText("Only number");
					rdbtnSexM.setSelected(true);
					rdbtnSexF.setSelected(false);
					txtGps.setText("Input GPS coordinate");
					txtSpecialInfo.setText("Write Special Information");
					textAreaReport.setText("Tracking Information");
					btnMakeRpt.setEnabled(false);
				}
				else if(cboName.getSelectedIndex() == 1) {
					txtSpecies.setText("Scientific Name");
					txtWeight.setText("Input Weight");
					txtGps.setText("00.0000000-00.0000000");				
					txtSpecialInfo.setText("Input Blood Pressure");
					textAreaReport.setText("Tracking Information");
					btnMakeRpt.setEnabled(true);
				}
				else if(cboName.getSelectedIndex() == 2) {
					txtSpecies.setText("Scientific Name");
					txtWeight.setText("Input Weight");
					txtGps.setText("00.0000000-00.0000000");
					txtSpecialInfo.setText("Input the number of sopts");
					textAreaReport.setText("Tracking Information");
					btnMakeRpt.setEnabled(true);
				}
				else if(cboName.getSelectedIndex() == 3) {
					txtSpecies.setText("Scientific Name");
					txtWeight.setText("Input Weight");
					txtGps.setText("00.0000000-00.0000000");
					txtSpecialInfo.setText("Input Dental Health(Good/Average/Poor)");
					textAreaReport.setText("Tracking Information");
					btnMakeRpt.setEnabled(true);
				}
			}
		});
		
		//Action Listeners for "Male" Radio button
		rdbtnSexM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rdbtnSexF.setSelected(false);
			}
		});
		
		//Action Listeners for "Male" Radio button
		rdbtnSexF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rdbtnSexM.setSelected(false);
			}
		});		
		
		//Action Listeners for "Make Report" button
		btnMakeRpt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			 if(validate.validateNumber(txtWeight.getText())==true) //Check validation for Weight (number) 
			 {			
				 if(GPS.regExpGPSInfo(txtGps.getText())==true)//Check the GPS coordinate regular expression 
				 {
					if(cboName.getSelectedIndex() == 1)//Selected Penguins 
					{	
						if(validate.checkDbSpcialInfo(txtSpecialInfo.getText())==true)//Check the Penguins' specialInfo validation = float number 
						{
							Penguins.setSpecies(txtSpecies.getText());//set Species to Penguins object from interface
							Penguins.setWeight(txtWeight.getText());//set Weight to Penguins object from interface						
							//set Sex to Penguins object from interface		
							if(rdbtnSexM.isSelected() == true)
								Penguins.setSex(true); // true = male
							else
								Penguins.setSex(false);// false = female
							Penguins.setGPSInfo(txtGps.getText());						
							//set Penguins' special information (Blood Pressure) to Penguins object from interface
							//set special information text to 'String SpecialInfo' from interface
							Penguins.setSpecialInfo(txtSpecialInfo.getText()); 
							//In case of penguins, set the special information into 'double bloodPressure'
							double bloodP = Double.parseDouble(Penguins.getSpecialInfo()); 
							Penguins.specialInfo(bloodP, 0, "");
							//Make report form
							Penguins.reportForm();
							//show the report in the screen (in textArea)
							textAreaReport.setText(Penguins.getRptForm());
							btnAddToList.setEnabled(true);
						}
						else
							JOptionPane.showMessageDialog(null,"Please input only number for Special info");	
					}//end Penguins' part
					
					else if(cboName.getSelectedIndex() == 2) //Selected SeaLions
					{
						if(validate.checkIntSpcialInfo(txtSpecialInfo.getText())==true) {
							SeaLions.setSpecies(txtSpecies.getText());
							SeaLions.setWeight(txtWeight.getText());
								
							if(rdbtnSexM.isSelected() == true)
								SeaLions.setSex(true); 
							else
								SeaLions.setSex(false);
			
							SeaLions.setGPSInfo(txtGps.getText());							
							SeaLions.setSpecialInfo(txtSpecialInfo.getText()); 
							int spots = Integer.parseInt(SeaLions.getSpecialInfo()); 
							SeaLions.specialInfo(0.0, spots, "");							
							SeaLions.reportForm();						
							textAreaReport.setText(SeaLions.getRptForm());
							btnAddToList.setEnabled(true);
						}
						else
							JOptionPane.showMessageDialog(null,"Please input only number for Special info");	
					}//end SeaLions' part
					
					else if(cboName.getSelectedIndex() == 3)//Selected Walrus
					{
							Walrus.setSpecies(txtSpecies.getText());
							Walrus.setWeight(txtWeight.getText());
				
							if(rdbtnSexM.isSelected() == true)
								Walrus.setSex(true); 
							else
								Walrus.setSex(false);
		
							Walrus.setGPSInfo(txtGps.getText());					
							Walrus.setSpecialInfo(txtSpecialInfo.getText()); 
							Walrus.specialInfo(0.0, 0, Walrus.getSpecialInfo());					
							Walrus.reportForm();
							textAreaReport.setText(Walrus.getRptForm());						
							btnAddToList.setEnabled(true);
					}//end Walrus' part
						
				 }
				 else
				 {
					 JOptionPane.showMessageDialog(null,"GPS coordinate is not valid expression."
						+ "\nPlease input the information as the Regular Expression");
				 }//end validation regular expression for GPS coordinate
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Please input pnly number for Weight info");	
			}//end validateNumber for weight	
		}	
	 });
		
		//Action Listeners for "Add to List" button: Add report to ArrayList
		btnAddToList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) { 
				if(cboName.getSelectedIndex() == 1) {
					reportList.add(Penguins.getRptForm());//Add the report form to (ArrayList)reportList 
				}
				else if(cboName.getSelectedIndex() == 2) {
					reportList.add(SeaLions.getRptForm());
				}
				else if(cboName.getSelectedIndex() == 3) {
					reportList.add(Walrus.getRptForm());
				}
				textAreaReport.setText("Added the information to List\n\nInput other information");
				btnAddToList.setEnabled(false);
				btnSaveFile.setEnabled(true);
			}
		});
		
		//Action Listeners for "Save to File" button: File I/O
		btnSaveFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ArrayList<String> temptList = new ArrayList<>();//Temporary ArrayList to load the exist contents of file

				FileIO.writeFile(temptList, reportList);//Save data to File  	
				
				//Interface control
				textAreaReport.setText("Save complete!");
				temptList.clear();
				reportList.clear();//Clear list for new report
				btnSaveFile.setEnabled(false);
			}
		});
		
		//Action Listeners for "Read File" button: Read file contents 
		btnReadFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
								
				//Interface control
				btnSaveFile.setEnabled(false);
				btnAddToList.setEnabled(false);
				btnMakeRpt.setEnabled(false);


				
				//String to show the data of file
				String savedData="Saved Report\n\n";

				//Read data from File
				savedData = FileIO.readFile(reportList, savedData);
						
				textAreaReport.setText(savedData);
				reportList.clear();//Clear list for new report				
			}
		});
		
	} 
}
