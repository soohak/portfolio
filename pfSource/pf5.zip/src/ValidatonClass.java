
public class ValidatonClass {

	protected boolean resultCheck;

	//constructor
	public ValidatonClass() {
		this.resultCheck = false;
	}

	//get & set methods
	public boolean isResultCheck() {
		return resultCheck;
	}

	public void setResultCheck(boolean resultCheck) {
		this.resultCheck = resultCheck;
	}
	
	//validation check for weight
	public boolean validateNumber(String num)
	{
		//loop through string verifying for numbers
		for(int i = 0;i<num.length(); i++)
		{
			char c = num.charAt(i);
			if(!Character.isDigit(c) && c !='.')
			{
				return false; //input include character
			}	
		}
		return true; //input is number
	}
	
	//Check Double data type for Penguins' special information from interface
	public boolean checkDbSpcialInfo(String num)
	{
		//loop through string verifying for numbers
		for(int i = 0;i<num.length(); i++)
		{
			char c = num.charAt(i);
			if(!Character.isDigit(c) && c !='.')
			{
				return false; //input include character
			}	
		}
		return true;  //input is number
	}
	
	
	//Check INT data type for Sea Lions' special information from interface
	public boolean checkIntSpcialInfo(String num)
	{
		//loop through string verifying for numbers
		for(int i = 0;i<num.length(); i++)
		{
			char c = num.charAt(i);
			if(!Character.isDigit(c))
			{
				return false; //input include character
			}	
		}
		return true;  //input is number
	}
}
