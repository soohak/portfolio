
public class Penguins extends Animal {

	protected double bloodPressure;
	
	@Override
	public void specialInfo(double bP, int NoS, String dentH) {// specialInfo() for Penguins
		String bPressure;
		this.bloodPressure = bP;
		bPressure = this.bloodPressure+" mmHg";
		this.setSpecialInfo(bPressure);
	}
	
	@Override
	public void reportForm() {
		String addRptForm;
		addRptForm = "Animal Name: "+this.getAniName()
				+"\nSpecies: "+this.getSpecies()
				+"\nSex: "+this.getSex()
				+"\nWeight: "+this.getWeight()+"Kg"
				+"\nGPS Coordinate: "+this.getGPSInfo()
				+"\nBlood Pressure: "+this.getSpecialInfo()+"\n\n";
		this.setRptForm(addRptForm);
	}
	
	//constructor
	public Penguins(){
		this.AniName = "Penguins";
		this.Species = "Spheniscidae";
		this.Sex = true;
		this.Weight = "Input Weight(Kg)";
		this.GPSInfo = "00.0000000-00.0000000";
		this.SpecialInfo = "Input Blood Pressure";
		this.RptForm = "Report";
	}
	
}
