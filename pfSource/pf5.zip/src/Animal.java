public abstract class Animal {
	
	protected String AniName;
	protected String Species;
	protected Boolean Sex;
	protected String Weight;
	protected String GPSInfo;  
	protected String SpecialInfo;
	protected String RptForm;
	
	//default constructor
	public Animal(){};

	//constructor
	public Animal(String aniName, String species, Boolean sex, String weight, String gPSInfo, String specialInfo,
			String rptForm) {
		super();
		AniName = aniName;
		Species = species;
		Sex = sex;
		Weight = weight;
		GPSInfo = gPSInfo;
		SpecialInfo = specialInfo;
		RptForm = rptForm;
	}

	//Set Special Information
	public abstract void specialInfo(double bP, int NoS, String dentH);

	//Set report form
	public abstract void reportForm();

	//get & set method
	public String getAniName() {
		return AniName;
	}

	public void setAniName(String aniName) {
		AniName = aniName;
	}
	
	public String getSpecies() {
		return Species;
	}

	public void setSpecies(String species) {
		this.Species = species;
	}

	public String getSex() {
		if(this.Sex==true)
			return "Male";
		else
			return "Female";
	}

	public void setSex(Boolean sex) {
		Sex = sex;
	}

	public String getWeight() {
		return Weight;
	}

	public void setWeight(String weight) {
		Weight = weight;
	}

	public String getGPSInfo() {
		return GPSInfo;
	}

	public void setGPSInfo(String gPSInfo) {
		GPSInfo = gPSInfo;
	}

	public String getSpecialInfo() {
		return SpecialInfo;
	}

	public void setSpecialInfo(String specialInfo) {
		SpecialInfo = specialInfo;
	}

	public String getRptForm() {
		return RptForm;
	}

	public void setRptForm(String rptForm) {
		RptForm = rptForm;
	}

}
