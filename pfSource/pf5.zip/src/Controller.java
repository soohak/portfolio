import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JOptionPane;

public class Controller {

	protected Path filePath;

	//Constructor
	public Controller(Path filePath) {
		this.filePath = filePath;
	}

	//File control methods (Read)
	public String readFile(ArrayList<String> list, String data){
			
		try {
			BufferedReader readerReport = Files.newBufferedReader(this.getFilePath());		
			String line = readerReport.readLine();		
			while(line!=null) {
				list.add(line);
				line = readerReport.readLine();
			}
			
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,"Could not read the file.");	
		}

		//show the data in report screen
		for(int i=0; i<list.size(); i++) {
			data += list.get(i)+"\n";
		}
		return data;
	}//end  readFile()
	
	//File control methods (Write)
	public void writeFile(ArrayList<String> tempList, ArrayList<String> currentList ){
		//Read exist file contents and load to Temporary ArrayList (For appending new data to exist data)
		try {
			BufferedReader readerReport = Files.newBufferedReader(this.getFilePath());//Read exist data from file
			String line = readerReport.readLine(); //read line by line
			while(line!=null) {
				tempList.add(line); //Input to Temporary ArrayList 
				line = readerReport.readLine();
			}				
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,"Could not read the file.");	
		}

		//Write new report information of reportList to file 
		try {
			BufferedWriter writeReport = Files.newBufferedWriter(this.getFilePath(), StandardCharsets.UTF_8);
			
			//Get current time
			Calendar currentTime = Calendar.getInstance();
			int year = currentTime.get(Calendar.YEAR);
			int month = currentTime.get(Calendar.MONTH);
			int days = currentTime.get(Calendar.DAY_OF_MONTH);
			int hours = currentTime.get(Calendar.HOUR);
			int min = currentTime.get(Calendar.MINUTE);
			String line ="Reported Date: "+year+"/"+month+"/"+days+", Time: "+hours+"h "+min+"m\n";
			
			//Write exist contents in File 
			for(int a=0; a<tempList.size(); a++){
				writeReport.write(tempList.get(a)+"\n"); //Record exist date to memory			
			}
			
			writeReport.write(line); //Record Recoding time		
			//Write new contents to appended 
			for(int i=0; i<currentList.size(); i++){
				writeReport.write(currentList.get(i)); //Record new data to memory after finish record exist date		
			}
			
			writeReport.flush(); //save whole data to file from memory
			writeReport.close(); //closing File Input		
			
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,"Could not write report.");	
		}
	}//end  writeFile()
	

		
	
	//get & set methods
	public Path getFilePath() {
		return filePath;
	}

	public void setFilePath(Path filePath) {
		this.filePath = filePath;
	}
		
}
