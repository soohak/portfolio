'use strict';

//Use validation class lib
let Helper = new validationCheck_Class("#userName");

//local storage for high-score and player name
let highScore = window.localStorage;

//Game score
let gameScore=0;
//For createElement of name and score
let name=0;
let score=0;

//Enemy fleet list Array from JSON
let enemyBattleship=[];
//Array for weather JSON from website
let arrayWeather=[];

//Set available click in Table
let btnCheck = false;
//Check 'td' click
let target_element="";


//Player battleship information
let numOfASM=30; //Anti-ship Missile Number
let numOfAAM=20; //Anti-aircraft missile Number
let numOfBullet=30000; //20mm*110mm Phalanx CIWS bullets number
let defense=5; //Shield's Limit for enemy attack

//Enemy information
let enemyLevel=0; //enemy level
let enemyShips=0; //enemy ships' number
let locationInfo = false; //Important factor to check enemy ships location
let xCoordiante=0;//x Coordinate of selected location
let yCoordiante=0;//y Coordinate of selected location
let target=0;
//Enemy missile speed & interval
let missileSpeed=0;
let missileInter=0;

//Time interval for enemy attack
let attackTime=0;
let movingTime=0;

let yc=0;
let xc=0;

//Element activation
let input=document.querySelectorAll('input');
let battleField=document.querySelectorAll('td'); //All td in Table
let infoBox=document.querySelectorAll('form'); //Form
let mainCanvas=document.querySelector('canvas');//canvas in 'radar' section
let radarScreen=document.querySelector('#radar'); //Section to display radar

//Open the JSON file for for enemy fleet information
function openEnemyInfo() {
    //button activation
    //element activation

    //open JSON file 'bookList.json'
    let request = new XMLHttpRequest();
    request.addEventListener('readystatechange', function () {
        if (this.readyState == 4 && this.status == 200) {
            enemyBattleship = JSON.parse(this.responseText);
            showEnemyInfo();
            cicInformation();
        }
    })
    request.open("GET", "./enemy_battleship/enemyBattleship.json");
    request.send();

    showDfRadar();
}

//Open the JSON from weather website for weather Information in CIC
function weatherInfo(){
    //weather informaiton in battleField
    let reqWeather = new XMLHttpRequest();
    // city id 5969423 means Halifax, my APPID used. Next time, I try to change city id by enemy information in JSON
    let url="http://api.openweathermap.org/data/2.5/weather?id=5969423&APPID=91d79342767003184c511e21533daa21";
    //parsing the JSON file from url (weather & temperature info.)
    reqWeather.addEventListener('readystatechange', function () {
        if (this.readyState == 4 && this.status == 200) {
            arrayWeather = JSON.parse(this.responseText);
            showWInfo(arrayWeather);
        }
    })
    reqWeather.open('GET', url, true);
    reqWeather.send();
}//end weatherInfo

//Drew battleship and the range of radar in canvas: I have to study more for understanding Canvas of HTML5
function showDfRadar(){
    radarScreen.style.backgroundImage ='url(./img/ocean.jpg)';
    radarScreen.style.backgroundRepeat = 'no-repeat';
    //Make the range of first radar as circle
    let firstRadar = mainCanvas.getContext("2d");
    firstRadar.beginPath();
    firstRadar.strokeStyle="#ff980f"
    firstRadar.lineWidth=1;
    firstRadar.arc(150,75,75,0,2*Math.PI,true);
    firstRadar.stroke();

    //Make the range of second radar as circle
    let secondRadar = mainCanvas.getContext("2d");
    secondRadar.beginPath();
    secondRadar.strokeStyle="#f90510"
    secondRadar.lineWidth=1;
    secondRadar.arc(150,79,37,0,2*Math.PI,true);
    secondRadar.stroke();

    //Input the image of battleship in the center of canvas
    let image = new Image();
    image.src="./img/battleship.png";
    image.onload=function () {
        firstRadar.drawImage(image, 140, 55, 15, 50);
    }
}//end showDfRadar

//Show the information for enemy fleet
function showEnemyInfo(){
    enemyLevel=Math.floor((Math.random()*enemyBattleship.length));
    let information= `Enemy Level: ${enemyBattleship[enemyLevel].level}`
    +`\nEnemy fleet: ${enemyBattleship[enemyLevel].fleet}`
    +`\nNumber of Enemy ships: ${enemyBattleship[enemyLevel].number}`
    +`\nMissile Speed: ${enemyBattleship[enemyLevel].m_speed}`;
    let textInfo= document.createElement('textarea');
    infoBox[0].appendChild(textInfo);
    textInfo.innerHTML=information;
    textInfo.disabled = true;
    enemyShips = enemyBattleship[enemyLevel].number;
    missileSpeed = enemyBattleship[enemyLevel].m_speed;
}//end showEnemyInfo

//Update by the result 'fire'button click -> attack result
function updateEnemyInfo(){
    let information= `Enemy Level: ${enemyBattleship[enemyLevel].level}`
        +`\nEnemy fleet: ${enemyBattleship[enemyLevel].fleet}`
        +`\nNumber of Enemy ships: ${enemyShips}`;
    let textInfo= document.createElement('textarea');
    infoBox[0].innerHTML="Enemy information";
    infoBox[0].appendChild(textInfo);
    textInfo.innerHTML=information;
    textInfo.disabled = true;
}//updateEnemyInfo()

//Show the information for player battle ship (CIC)
function cicInformation(){
    //CIC information setting
    let information= `Anti-ship Missile: Harpoon ${numOfASM}`
        +`\nAnti-aircraft missile: ${numOfAAM}`
        +`\nClose-in Weapon System: 20mm Phalanx CIWS ${numOfBullet} bullets`
        +`\nDefense shield Limit: ${defense}`;
    let txtBox=document.createElement('textarea');
    infoBox[1].appendChild(txtBox);
    txtBox.innerHTML=information;
    txtBox.disabled = true;
}//end cicInformation

//Show the information for player battleship when the information changed
function updateCICInformation(){
    let information= `Anti-ship Missile: Harpoon ${numOfASM}`
        +`\nAnti-aircraft missile: ${numOfAAM}`
        +`\nClose-in Weapon System: 20mm Phalanx CIWS ${numOfBullet} bullets`
        +`\nDefense shield Limit: ${defense}`;
    let txtBox=document.createElement('textarea');
    infoBox[1].innerHTML="Weapon Information";
    infoBox[1].appendChild(txtBox);
    txtBox.innerHTML=information;
    txtBox.disabled = true;
}//end cicInformation

//Show the weather information in CIC
function showWInfo(arr) {
    //show the Temperature and Weather Icon
    let tempC = arr.main.temp - 273.15; //alter to Celsius from array
    let temp = `<b>Current Temperature: </b>${tempC.toFixed(1)}&deg;C`;
    let weatherIcon = `<br><img src="http://openweathermap.org/img/w/${arr.weather[0].icon}.png">`;
    let infoWeather1=document.createElement('h5');
    infoBox[3].appendChild(infoWeather1);
    infoWeather1.innerHTML=temp+weatherIcon;
}//end showWInfo

//Game start by start button: this method is main key part
function gameStart(){

    if(Helper.checkInputText("#userName")==true)//valid name
    {
        //Back Ground Music
        BGM();

        //Arrangement enemy ship in battlefield automatically
        //1. Set all td's value false, 'false' in coordinate is empty location
        for(let l=0; l<battleField.length; l++){
            battleField[l].value=false;
            battleField[l].id = l;
        }
        //2. Set enemy ship location
        for(let e=0; e<enemyShips; e++){
            let lock = true;
            let locationNum=0;

            while(lock){
                locationNum=Math.floor((Math.random()*battleField.length));//make random location
                if(battleField[locationNum].value == false)//prevent duplication
                {
                    //If you want to check the location of the enemy, debug 'locationNum' in here by the inspection function
                    battleField[locationNum].value = true;//'true' mean that enemy ships is located in this coordinate
                    lock = false;
                }
            }
        }
        //start enemy attack
        if(missileSpeed==1){
            missileInter=4000;
        }
        else if(missileSpeed==2){
            missileInter=3000;
        }
        else if(missileSpeed==3){
            missileInter=1500;
        }
        //start enemy attack
        attackTime=setInterval(enemyAttack,missileInter);

        //Disabled text input 'name'
        input[0].disabled = true;

        //Display name and score
        nameNScore();

        //check local storage for high score and display
        checkHighScore();

        //disabled this button by game finished
        input[1].disabled = true;

        //Activate table to select coordinate
        btnCheck = true;
    }
    else//Not valid input for name
    {
        input[0].value = "Input only alphabet (No space)";
    }
}//end gameStart

//Put the selected Coordinate into text input
function selectCoordinate(){
        //select target
        target_element = this;
        if(btnCheck == true)//if table contact is available
        {
            //image effect in target by the 'click' event
            target_element.style.backgroundImage ='url(./img/bomb.png)';
            locationInfo=this.value;//factor to check enemy ships location
            xCoordiante=this.cellIndex;//set x Coordinate of selected locations (cellIndex is td identification)
            yCoordiante=this.parentNode.cells[0].innerHTML;//Get a alphabet 'A~G' as the 'y Coordinate' of selected location
            target=this.id;
            input[3].value= yCoordiante+xCoordiante.toString();//combinate two coordinate and put this into 'text'

            //activate fire button
            input[4].disabled = false;
            //disable to select 'td' in table until fire button clicked
            btnCheck = false;
        }
}

//fire button
function missileLaunch(){

    //sound effect 'missile launching
    launching();

    let targetNum = parseInt(target);

    if(locationInfo==true){
		//sound effect
        explosion();
        gameScore=gameScore+1; //plus score
        score.innerHTML="[Score: "+gameScore+"]";

       //image effect in target by the 'hit' event
        battleField[targetNum].style.backgroundImage ='url(./img/ship.png)';
        battleField[targetNum].innerHTML="Hit!";
        battleField[targetNum].value=false;
        enemyShips = enemyShips-1;
        updateEnemyInfo();
    }
    else{
        //image effect for 'miss' event
        battleField[targetNum].style.backgroundImage ='url(./img/miss.png)';
        battleField[targetNum].disabled=true;
    }

    numOfASM = numOfASM-1;

    updateCICInformation();

    btnCheck = true;
    input[4].disabled = true;

    if(numOfASM==0 && enemyShips>0){
        youDefeat();
    }
    else if(enemyShips==0){
        youWin();
    }
}

//enemy attack
function enemyAttack(){
    // the coordinate that enemy missile is destroyed by defense system
    xc=Math.floor((Math.random()*140)+75);
    yc=Math.floor((Math.random()*35)+10);

    movingTime=setInterval(missileMove, 500);
}

//moving missile
function missileMove(){

    let enMissile = mainCanvas.getContext("2d");
    enMissile.beginPath();
    enMissile.fillStyle="#ff1624";
    enMissile.arc(xc,yc,2,0,Math.PI*2,true);
    enMissile.closePath();
    enMissile.fill();

    if(xc>0 && xc<150)
        xc=xc+6;
    if(xc>150 && xc<201)
        xc=xc-6;
    yc=yc+6;

    if(yc>47){
        clearInterval(movingTime);
        defenseSystem(xc, yc);
        xc=Math.floor((Math.random()*140)+75);
        yc=Math.floor((Math.random()*35)+10);
    }
}


//Working defense system for enemy missile
function defenseSystem(xd, yd) {
    //first defense: Anti-aircraft missile
    let secondWeapon=false;
    let shieldSystem=false;

    if(numOfAAM>=0){
        numOfAAM=numOfAAM-1;
    }
    //change defense system
    if(numOfAAM<0){
        secondWeapon=true;
        numOfAAM=0;
    }
    //second defense: Close-in Weapon System
    if(secondWeapon==true && numOfBullet>=0)
    {
        numOfBullet=numOfBullet-5000;
    }
    //change defense system
    if(numOfBullet<1){
        secondWeapon = false;
        shieldSystem = true;
    }
    //last defense: Defense shield
    if(secondWeapon==false && shieldSystem==true){
        defense = defense-1;
    }
    //defeat: do not destroy all enemy ship before run out defense weapon
    if(defense<1 && enemyShips>0){
		defense = 0;
        youDefeat();
    }
	
	//show the location of destroyed missile
    let destroyed = mainCanvas.getContext("2d");
    destroyed.beginPath();
    destroyed.fillStyle="#4b35ff";
    destroyed.arc(xd,yd,2,0,Math.PI*2,true);
    destroyed.closePath();
    destroyed.fill();

    //update CIC information for using weapon
    updateCICInformation();
}

//Game Restart
function resetGame(){//Game reset for reset_button
    document.location.reload();
}//end resetGame

//display name and score
function nameNScore(){
    name=document.createElement('p');
    score=document.createElement('p');
    infoBox[2].appendChild(name);
    name.innerHTML="CAPTAIN: "+input[0].value;
    infoBox[2].appendChild(score);
    score.innerHTML="CURRENT SCORE: "+gameScore;
}

//check and display the high score in local storage
function checkHighScore(){
        //get info from local storage
        let topPlay=highScore.getItem('name');
        let topScore=highScore.getItem('score');

        //show the information
        let bestPlayer=document.createElement('p');
        infoBox[2].appendChild(bestPlayer);
        bestPlayer.innerHTML="[[Best Player: "+topPlay+", Top Score: "+topScore+"]]";
}//end checkHighScore

//save high score in local storage
function saveHighScore() {
    if (highScore.getItem('score') == null) {
        highScore.setItem('name', input[0].value);
        highScore.setItem('score', gameScore);
    }
    else {
        if (highScore.getItem('score') <= gameScore)
        {
            highScore.setItem('name', input[0].value);
            highScore.setItem('score', gameScore);
        }
    }
}//end saveHighScore

//show the result for defeat
function youDefeat(){
    //stop timer for enemy missile
    clearInterval(movingTime);
    clearInterval(attackTime);

    //report the result
    let textInfo= document.createElement('textarea');
    infoBox[0].innerHTML="Combat Report";
    infoBox[0].appendChild(textInfo);
    textInfo.innerHTML="You Defeated!!!";

    //show the enemy ships' location
    for(let i=0; i<battleField.length; i++){
        if(battleField[i].value==true){
            battleField[i].style.backgroundColor="yellow";
            battleField[i].innerHTML="Here!";
        }
    }

    //button validation control
    input[2].disabled = false;
    btnCheck = false;

    //save the high score in local storage
    saveHighScore();
}//end youDefeat

//show the result for win
function youWin(){
    //stop timer for enemy missile
	clearInterval(movingTime);
    clearInterval(attackTime);

    //report the result
    let textInfo= document.createElement('textarea');
    infoBox[0].innerHTML="Combat Report";
    infoBox[0].appendChild(textInfo);
    textInfo.innerHTML="You Win!!!";

    //button validation control
    input[2].disabled = false;
    btnCheck = false;

    //save the high score in local storage
    saveHighScore();
}//end youWin

// Set up the initialize screen
window.addEventListener('load',function(){
	openEnemyInfo();
    weatherInfo();

    //event listeners
    input[0].addEventListener('click', function (){//reset in text input
        input[0].value="";});
    input[1].addEventListener('click', gameStart);
    input[2].addEventListener('click', resetGame);
    input[4].addEventListener('click', missileLaunch);

    //td event listener for clicking
    for(let i=0; i<battleField.length; i++){
        battleField[i].addEventListener('click', selectCoordinate);
    }

    //cheat key for test ^^ After click 'Game Start' button and click 'footer' ^^ ho~ho~ho~
    let cheat=document.querySelector('footer');
    cheat.addEventListener('click', function (){//show the enemy location
        for(let i=0; i<battleField.length; i++){
            if(battleField[i].value==true){
                battleField[i].innerHTML="Here!";
            }
        }
    });
});

/************ Sound Effects ************/
function BGM(){
    //Background Music, Wikipedia Free sound : Tchaikovsky  The Nutcracker Suite Op.71a  VIII Flower Waltz (The Nutcracker Suite Op.71a  VIII Flower Waltz) - Alexander Lazarev
    let background_music = `<audio src="./sound/backGroundMusic.mp3" autoplay loop></audio>`;
    document.querySelector('#BGM').innerHTML = background_music;
}

function launching(){
    //Free effect sound from "SoundEffect++" : https://www.soundeffectsplus.com
    let missileLaunch = `<audio src="./sound/launching.mp3" autoplay></audio>`;
    document.querySelector('#launch').innerHTML = missileLaunch;
}

function explosion(){
    //Free effect sound from "SoundEffect++" : https://www.soundeffectsplus.com
    let explosion = `<audio src="./sound/explosion.mp3" autoplay></audio>`;
    document.querySelector('#explosion').innerHTML = explosion;
}
