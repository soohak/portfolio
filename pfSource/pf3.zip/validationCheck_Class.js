class validationCheck_Class {

    constructor(cssSelector){
        this.css = cssSelector;
    }

    checkInputText() {
        let textForm = document.querySelector(this.css);
        let inputText = textForm.value;
        //I use the regular expression to check other character except alphabet character
        //I refer below regular expression '/[^a-z]/' from my textbook and the Internet
        let re = /[^a-z]/;
        let checkNum=0;

        for(let i=0; i<inputText.length; i++)
        {
            let result = inputText[i].toLowerCase().match(re);
            if(result!=null)
                checkNum=checkNum+1; //include number and other symbol
        }

        if(checkNum>0 || inputText=="")
            return false; //input has number, symbol or empty
        else
            return true; // only alphabet character

    }

}//end class


