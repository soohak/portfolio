import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
import java.awt.event.*;
import javax.swing.Timer;
import java.awt.Graphics;


public class ScreenSaver extends JPanel{

	private Timer timer = new Timer(10, new TimerHandler());
	
	//Array for color change of graphics
	Color colorArray[]= {Color.RED,Color.BLUE, Color.GREEN,Color.ORANGE,Color.MAGENTA,Color.BLACK, Color.YELLOW, Color.CYAN
			,Color.PINK, Color.DARK_GRAY};
	
	//To change graphic pattern
	private JButton btnNewButton; //button for pattern changing
	private int clickOpt=0; //arg for pattern changing
	
	//For shape#4 packman, mouth and movement
	private int mouth1=0;
	private int mouth2=320;
	private int mouth3=240;
	private int mouth4=280;
	private Boolean turn1= true;
	private Boolean turn2= true;
	private int mf=0;
	private int mb=1920;
	
	//Constructor
	public ScreenSaver()
	{
		//setLayout(null);		

		btnNewButton = new JButton("Change Pattern");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(0, 0, 120, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clickOpt = clickOpt+1;
				if(clickOpt>3)
					clickOpt=0;	
			}
		});
		this.add(btnNewButton);
		
		timer.start();
		
	}//end constructor
		
	//Graphic Generator
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);//prevents graphics errors
		Graphics2D g2d1 = (Graphics2D) g;
		Graphics2D g2d2 = (Graphics2D) g;

		//Change color
		int rColor = (int)(Math.random()*10);
		g2d1.setPaint(colorArray[rColor]);

		//First level: Shape#1-Line
		if(clickOpt==0) {
		
			//make random coordinate
			int rx= (int)(Math.random()*1920);
			int ry= (int)(Math.random()*1080);
			int rl = (int)(Math.random()*1080);
			int re = (int)(Math.random()*1080);
			
			//Draw lines
			g2d1.draw(new Line2D.Double(rx, ry, rl, re));
		
		}//end shape#1
		
		//Second level: Shape#1 + Shape#2-Rectangle
		else if(clickOpt==1) {
			
			//Shape#1-Line
			int rx= (int)(Math.random()*1920);
			int ry= (int)(Math.random()*1080);
			int rl = (int)(Math.random()*1080);
			int re = (int)(Math.random()*1080);
			g2d1.draw(new Line2D.Double(rx, ry, rl, re));
			
			//Shape#2-Rectangle
			//make random coordinate
			int Recx= (int)(Math.random()*1920);
			int Recy= (int)(Math.random()*1080);
			int veti= (int)(Math.random()*100+100);
			int hori= (int)(Math.random()*100+100);
			//Draw Rectangle
			g2d1.fill(new Rectangle2D.Double(Recx, Recy, veti, hori));

		}//end shape#2
		
		//Third level: Shape#1 & Shape#2 + Shape#3-Circle
		else if(clickOpt==2) {
			//Shape#1-Line
			int rx= (int)(Math.random()*1920);
			int ry= (int)(Math.random()*1080);
			int rl = (int)(Math.random()*1080);
			int re = (int)(Math.random()*1080);
			g2d1.draw(new Line2D.Double(rx, ry, rl, re));
			
			//Shape#2-Rectangle
			int Recx= (int)(Math.random()*1920);
			int Recy= (int)(Math.random()*1080);		
			int veti= (int)(Math.random()*100+100);
			int hori= (int)(Math.random()*100+100);
			g2d1.fill(new Rectangle2D.Double(Recx, Recy, veti, hori));
	
			
			//Shape#3-Circle
			//make random coordinate
			int Cx= (int)(Math.random()*1920);
			int Cy= (int)(Math.random()*1080);
			int pi= (int)(Math.random()*100+100);
			g2d1.fill(new Ellipse2D.Double(Cx, Cy, 65, pi));
		
		}//end shape#3
		
		//Last level: Shape#1 & Shape#2 & Shape#3 + Shape4#: Moving Pack Man
		else if(clickOpt==3) {
			//Shape#1-Line
			int rx= (int)(Math.random()*1920);
			int ry= (int)(Math.random()*1080);
			int rl = (int)(Math.random()*1080);
			int re = (int)(Math.random()*1080);
			g2d1.draw(new Line2D.Double(rx, ry, rl, re));
			
			//Shape#2-Rectangle
			int Recx= (int)(Math.random()*1920);
			int Recy= (int)(Math.random()*1080);		
			int veti= (int)(Math.random()*100+100);
			int hori= (int)(Math.random()*100+100);
			g2d1.fill(new Rectangle2D.Double(Recx, Recy, veti, hori));
			
			//Shape#3-Circle
			int Cx= (int)(Math.random()*1920);
			int Cy= (int)(Math.random()*1080);
			int pi= (int)(Math.random()*100+100);
			g2d1.fill(new Ellipse2D.Double(Cx, Cy, 65, pi));
			
			
			//Shape#4-PackMan	
			g2d2.setStroke(new BasicStroke(6.0f));		
			//Move to left
			if(turn1){//mouth closing
				g2d2.setPaint(Color.RED);
				mouth2++;
				mf++;
				if(mouth2 >= 360)
					turn1 = false;
			}
			else{//mouth open
				g2d2.setPaint(Color.ORANGE);
				mouth2--;
				mf++;
				if(mouth2 <= 320)
					turn1 = true;
			}
			
			if(mf>1920) {//moving start from left side
				mf=0;
			}		
			//Draw pack man
			g2d2.draw(new Arc2D.Double(mf, 20, 70, 100,mouth1, mouth2, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+40, 40, 10, 10, 0, 220, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+100, 70, 10, 10, 0, mouth2, Arc2D.PIE));	
				
			g2d2.draw(new Arc2D.Double(mf+100, 140, 70, 100,mouth1, mouth2, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+140, 160, 10, 10, 0, 220, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+200, 190, 10, 10, 0, mouth2, Arc2D.PIE));
			
			g2d2.draw(new Arc2D.Double(mf, 500, 70, 100,mouth1, mouth2, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+40, 520, 10, 10, 0, 220, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+100, 550, 10, 10, 0, mouth2, Arc2D.PIE));
			
			g2d2.draw(new Arc2D.Double(mf+100, 620, 70, 100,mouth1, mouth2, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+140, 640, 10, 10, 0, 220, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mf+200, 690, 10, 10, 0, mouth2, Arc2D.PIE));
				
			//Move to right
			if(turn2){//mouth closing
				g2d2.setPaint(Color.BLUE);
			mouth4++;
			mb--;
			if(mouth4 >= 320)
				turn2 = false;
			}
			else{//mouth open
				g2d2.setPaint(Color.GREEN);
				mouth4--;
				mb--;
				if(mouth4 <= 280)
					turn2 = true;
			}
			
			if(mf<=0) {//moving start from left side
				mb=	1920;
			}
			
			int hopJump= (int)(Math.random()*50);//hopping mini-circle
			//Draw pack man
			g2d2.draw(new Arc2D.Double(mb, 260, 70, 100, mouth3, mouth4, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+20, 280, 10, 10, 0, 45, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb-60+hopJump, 310, 10, 10, 0, 365, Arc2D.PIE));	
			
			g2d2.draw(new Arc2D.Double(mb+100, 380, 70, 100, mouth3, mouth4, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+120, 400, 10, 10, 0, 45, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+40, 430+hopJump, 10, 10, 0, 365, Arc2D.PIE));	
			
			g2d2.draw(new Arc2D.Double(mb, 740, 70, 100, mouth3, mouth4, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+20, 760, 10, 10, 0, 45, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb-60+hopJump, 790, 10, 10, 0, 365, Arc2D.PIE));	
			
			g2d2.draw(new Arc2D.Double(mb+100, 860, 70, 100, mouth3, mouth4, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+120, 880, 10, 10, 0, 45, Arc2D.PIE));
			g2d2.draw(new Arc2D.Double(mb+40, 910+hopJump, 10, 10, 0, 365, Arc2D.PIE));	
		
		}//end shape#4
		
	}//end paintComponent
	



	public class TimerHandler implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent arg0){
			repaint();//this calls the paintComponent method above
		}
		
	}
}//end class
